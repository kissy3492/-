@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"

title 相続インサイト 統合分析版
set "APP=%~dp0souzoku_insight_app.py"
set "DATA_DIR=%~dp0souzoku_insight_data"

echo ========================================
echo 相続インサイト 統合分析版 起動
echo ========================================
echo.

if not exist "%APP%" (
  echo [ERROR] souzoku_insight_app.py が見つかりません。
  echo ZIPを開いた中で直接実行している可能性があります。
  echo 必ずZIPを右クリックして「すべて展開」してから、このファイルを実行してください。
  echo.
  pause
  exit /b 1
)
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>nul

call :FIND_PYTHON
if errorlevel 1 goto NO_PYTHON

echo [1] Python確認
call :RUN_PY -c "import sys; print(sys.version.split()[0]); raise SystemExit(0 if sys.version_info >= (3,8) else 1)"
if errorlevel 1 goto BAD_PYTHON

echo.
echo [2] 起動前診断
call :RUN_PY "%APP%" --startup-check > "%DATA_DIR%\startup_check.json" 2> "%DATA_DIR%\startup_check_error.txt"
if errorlevel 1 (
  echo [ERROR] 起動前診断で問題が出ました。
  echo.
  type "%DATA_DIR%\startup_check.json" 2>nul
  type "%DATA_DIR%\startup_check_error.txt" 2>nul
  echo.
  echo 詳細は souzoku_insight_data\startup_check.json を確認してください。
  pause
  exit /b 1
)
type "%DATA_DIR%\startup_check.json"

echo.
echo [3] サーバーを起動します。
echo Edgeが自動で開かない場合は、この画面のURLをEdgeへ直接貼り付けてください。
echo 終了する場合は、この黒い画面で Ctrl+C を押してください。
echo.

rem Python側の自動ブラウザ起動が無反応な環境に備え、少し遅らせてURL読取起動も並行します。
start "" "%ComSpec%" /c "timeout /t 2 /nobreak >nul & call ""%~dp0open_app.bat"""
call :RUN_PY "%APP%" --server --port 8765 --open
set "EXITCODE=%ERRORLEVEL%"
echo.
echo サーバーが終了しました。終了コード: %EXITCODE%
echo 起動できなかった場合は、diagnose.bat を実行してください。
pause
exit /b %EXITCODE%

:FIND_PYTHON
set "PY_MODE="
set "PYTHON_EXE="
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY_MODE=PYLAUNCHER"
  exit /b 0
)
for %%C in (python python3) do (
  for /f "delims=" %%P in ('where %%C 2^>nul') do (
    "%%P" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
    if not errorlevel 1 (
      set "PY_MODE=PYTHON"
      set "PYTHON_EXE=%%P"
      exit /b 0
    )
  )
)
exit /b 1

:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" (
  py -3 %*
) else (
  "%PYTHON_EXE%" %*
)
exit /b %ERRORLEVEL%

:NO_PYTHON
echo [ERROR] Python 3.8以上が見つかりません。
echo py -3 / python / python3 のいずれかで Python が起動できる必要があります。
echo Microsoft Storeの案内だけが開く場合は、Python本体をインストールするか、アプリ実行エイリアスを無効にしてください。
echo Pythonなしで最低限開く場合は STANDALONE.html を開いてください。ただしPython連携出力は使えません。
pause
exit /b 1

:BAD_PYTHON
echo [ERROR] Pythonは見つかりましたが、3.8未満または正常起動できません。
echo Pythonなしで最低限開く場合は STANDALONE.html を開いてください。ただしPython連携出力は使えません。
pause
exit /b 1
