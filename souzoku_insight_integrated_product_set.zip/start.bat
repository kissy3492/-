@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 souzoku_insight_app.py --server --open || python souzoku_insight_app.py --server --open
pause
