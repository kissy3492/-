@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo Python確認:
where py >nul 2>nul
if not errorlevel 1 (
  py -3 --version
  echo.
  echo 検証ゲートを実行します...
  py -3 check_gate.py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] Python が見つかりません。
    pause
    exit /b 1
  )
  python --version
  echo.
  echo 検証ゲートを実行します...
  python check_gate.py
)
echo.
echo 診断終了。
pause
