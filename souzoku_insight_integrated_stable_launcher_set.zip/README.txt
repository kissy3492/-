相続インサイト 統合分析版

■通常の起動
1. ZIPを必ず展開する
2. start.bat をダブルクリックする
3. 黒い画面に表示される URL を Edge で開く
   通常は自動で開きます。

■今回の起動方式
start.bat は、サーバーを別ウィンドウで無理に起動しません。
同じ黒い画面で、起動前診断 → サーバー起動 → URL表示まで行います。
これにより、引用符崩れ・別ウィンドウ起動失敗・URL検出失敗を避けます。

■開かない場合
1. 黒い画面に表示された http://127.0.0.1:xxxx/ をEdgeへ直接貼り付ける
2. open_app.bat を実行する
3. diagnose.bat を実行して診断結果を見る
4. run_console.bat を実行してエラーを閉じずに確認する

■保存先
運用データは souzoku_insight_data フォルダに保存されます。
起動前診断の結果は souzoku_insight_data/startup_check.json です。
起動中URLは souzoku_insight_data/current_url.txt です。

■検証
check_gate.py を実行すると、配布ファイル、SHA256、HTML/JS構文、既存機能保持、分析ルール、HTTP/API、案件パッケージ、起動前診断を確認します。

■ファイル
souzoku_insight_app.py : 統合アプリ本体
start.bat              : 通常起動
open_app.bat           : 起動済み画面を開く
run_console.bat        : エラー確認起動
diagnose.bat           : 診断
OPEN_THIS.html         : ブラウザ側から起動中サーバーを探す補助ページ
check_gate.py          : 検証ゲート
SHA256.txt             : 配布ファイルのハッシュ
