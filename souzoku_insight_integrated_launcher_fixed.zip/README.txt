相続インサイト 統合分析版

■最初に使うファイル
START_HERE.cmd を実行してください。
日本語名が見やすい環境では 起動.bat でも同じです。

■通常の起動
1. ZIPを必ず「すべて展開」する
2. 展開後フォルダ内の START_HERE.cmd をダブルクリックする
3. 黒い画面を閉じずに待つ
4. Edgeが自動で開かない場合は、黒い画面に表示される http://127.0.0.1:xxxx/ をEdgeへ貼り付ける

■Pythonなしで最低限開く場合
STANDALONE.html を開いてください。
これは画面確認・通常HTML処理用の退避導線です。
Python連携の案件DB、監査ログ、Excel/SQLite入り案件パッケージ保存は START_HERE.cmd 起動時のみ使えます。

■開かない場合
1. ZIPを展開せずに中から直接起動していないか確認する
2. START_HERE.cmd を実行する
3. 黒い画面にURLが出ているなら、そのURLをEdgeに貼り付ける
4. open_app.bat を実行する
5. diagnose.bat を実行し、エラー表示を見る
6. Pythonが見つからない場合は STANDALONE.html で最低限開く

■保存先
運用データは souzoku_insight_data フォルダに保存されます。
起動前診断の結果は souzoku_insight_data/startup_check.json です。
起動中URLは souzoku_insight_data/current_url.txt です。

■ファイル
START_HERE.cmd        : 推奨起動入口
起動.bat              : START_HERE.cmd と同じ起動入口
souzoku_insight_app.py : 統合アプリ本体
start.bat              : 通常起動本体
open_app.bat           : 起動済み画面を開く
diagnose.bat           : 診断
run_console.bat        : エラー確認起動
OPEN_THIS.html         : 起動済みサーバーを探す補助ページ
STANDALONE.html        : Pythonなしで開く退避用単体HTML
check_gate.py          : 検証ゲート
SHA256.txt             : 配布ファイルのハッシュ
