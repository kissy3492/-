@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "URL_FILE=%~dp0souzoku_insight_data\current_url.txt"
set "APP_URL="
if exist "%URL_FILE%" set /p APP_URL=<"%URL_FILE%"
if "%APP_URL%"=="" set "APP_URL=http://127.0.0.1:8765/"
echo Opening: %APP_URL%
where msedge >nul 2>nul
if not errorlevel 1 (
  start "" msedge "%APP_URL%"
) else (
  start "" "%APP_URL%"
)
exit /b 0
