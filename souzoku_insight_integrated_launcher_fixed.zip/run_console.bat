@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title 相続インサイト エラー確認起動
echo ========================================
echo 相続インサイト 統合分析版 エラー確認起動
echo ========================================
echo.
echo この画面ではエラーを閉じずに確認できます。
echo.
call "%~dp0start.bat"
echo.
echo 上に出たエラー文を確認してください。
pause
