相続インサイト 統合分析版

■ 起動方法
1. ZIPを必ず展開する
2. start.bat をダブルクリックする
3. 「相続インサイト サーバー」という別ウィンドウが開く
4. Edgeが開く。開かない場合は start.bat に表示されたURLをEdgeへ貼り付ける

■ 開けない場合
- open_app.bat: 既に起動している画面URLを開く
- run_console.bat: 1つの黒い画面で起動し、エラーを確認する
- diagnose.bat: Pythonと検証ゲートを確認する

■ 通常使うファイル
- start.bat

■ アプリ本体
- souzoku_insight_app.py
  画面HTML、分析API、案件DB、監査ログ、Excel/SQLite/案件パッケージ出力を含む統合アプリ。

■ 保存先
- souzoku_insight_data/
  案件DB、監査ログ、current_url.txt が作成される。

■ 終了方法
「相続インサイト サーバー」ウィンドウで Ctrl+C を押す。

■ 注意
HTML単体版とは別に使う統合Python版です。
画面は http://127.0.0.1:ポート番号/ で開きます。
入力データはローカルPC内で処理されます。
