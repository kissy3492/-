@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

set "APP=souzoku_insight_app.py"
set "DATA_DIR=%CD%\souzoku_insight_data"
set "URL_FILE=%DATA_DIR%\current_url.txt"

if not exist "%APP%" (
  echo [ERROR] %APP% が見つかりません。
  echo ZIPを必ず展開してから、展開したフォルダ内の start.bat を実行してください。
  pause
  exit /b 1
)

where py >nul 2>nul
if not errorlevel 1 (
  set "PY_EXE=py"
  set "PY_ARGS=-3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] Python が見つかりません。
    echo Python 3 をインストールするか、py または python コマンドが使える状態にしてください。
    echo.
    echo 確認用: diagnose.bat を実行すると、同じ内容を確認できます。
    pause
    exit /b 1
  )
  set "PY_EXE=python"
  set "PY_ARGS="
)

echo 使用するPython:
"%PY_EXE%" %PY_ARGS% --version
echo.
echo サーバー用の別ウィンドウを開きます。
echo その後、この画面がURLを読んでEdgeを開きます。
echo.

if exist "%URL_FILE%" del "%URL_FILE%" >nul 2>nul

start "相続インサイト サーバー" cmd /k ""%PY_EXE%" %PY_ARGS% "%APP%" --server --port 8765"

echo 起動URLの作成を待っています...
for /l %%I in (1,1,20) do (
  if exist "%URL_FILE%" goto GOT_URL
  timeout /t 1 /nobreak >nul
)

set "APP_URL=http://127.0.0.1:8765/"
echo [WARN] current_url.txt がまだ作成されていません。
echo サーバー用ウィンドウにエラーが出ていないか確認してください。
echo いったん既定URLを開きます: %APP_URL%
goto OPEN_URL

:GOT_URL
set /p APP_URL=<"%URL_FILE%"
echo 起動URL: %APP_URL%

:OPEN_URL
where msedge >nul 2>nul
if not errorlevel 1 (
  start "" msedge "%APP_URL%"
) else (
  start "" "%APP_URL%"
)

echo.
echo Edgeが開かない場合は、下のURLをコピーしてEdgeのアドレス欄に貼り付けてください。
echo %APP_URL%
echo.
echo サーバーを終了する場合は、「相続インサイト サーバー」ウィンドウで Ctrl+C を押してください。
pause
exit /b 0
