@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0insight_engine.py" --server --port 8765
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python "%~dp0insight_engine.py" --server --port 8765
  ) else (
    echo Python 3 was not found. Please install Python 3 and run again.
  )
)
pause
