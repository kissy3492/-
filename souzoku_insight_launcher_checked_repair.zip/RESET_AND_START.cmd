@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo Resetting old Souzoku Insight launcher processes...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$procs=Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'souzoku_insight_app\.py' }; foreach($p in $procs){ try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop; Write-Host ('Stopped process ' + $p.ProcessId) } catch { Write-Host ('Failed to stop process ' + $p.ProcessId + ': ' + $_.Exception.Message) } }"
echo Starting...
wscript.exe "%~dp0start_hidden.vbs"
exit /b 0
