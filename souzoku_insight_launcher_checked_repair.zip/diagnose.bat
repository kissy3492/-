@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "APP=%~dp0souzoku_insight_app.py"

echo ========================================
echo Souzoku Insight diagnose
echo ========================================
echo.
if not exist "%APP%" (
  echo [ERROR] souzoku_insight_app.py was not found. Extract the ZIP first.
  pause
  exit /b 1
)
call :FIND_PYTHON
if errorlevel 1 goto NO_PYTHON

echo [1] Python version
call :RUN_PY -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info >= (3,8) else 1)"
if errorlevel 1 goto ERR

echo.
echo [2] Python syntax
call :RUN_PY -m py_compile "%APP%"
if errorlevel 1 goto ERR

echo.
echo [3] Startup check
call :RUN_PY "%APP%" --startup-check > "%~dp0souzoku_insight_data\diagnose_startup_check.json" 2> "%~dp0souzoku_insight_data\diagnose_startup_error.txt"
if errorlevel 1 goto ERR
echo Startup check OK.

echo.
echo [4] Gate check
call :RUN_PY "%~dp0check_gate.py"
if errorlevel 1 goto ERR

echo.
echo Diagnose OK. Run START_HERE.cmd.
pause
exit /b 0

:FIND_PYTHON
set "PY_MODE="
set "PYTHON_EXE="
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
if not errorlevel 1 ( set "PY_MODE=PYLAUNCHER" & exit /b 0 )
for %%C in (python python3) do (
  for /f "delims=" %%P in ('where %%C 2^>nul') do (
    "%%P" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
    if not errorlevel 1 ( set "PY_MODE=PYTHON" & set "PYTHON_EXE=%%P" & exit /b 0 )
  )
)
exit /b 1

:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" ( py -3 %* ) else ( "%PYTHON_EXE%" %* )
exit /b %ERRORLEVEL%

:NO_PYTHON
echo [ERROR] Python 3.8 or later was not found.
echo Open STANDALONE.html for fallback mode.
pause
exit /b 1

:ERR
echo.
echo [ERROR] Diagnose failed. Check the message above.
pause
exit /b 1
