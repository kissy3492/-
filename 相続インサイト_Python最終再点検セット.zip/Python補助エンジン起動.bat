@echo off
cd /d %~dp0
py -3 "%~dp0相続インサイト補助エンジン.py" --server --port 8765
pause
