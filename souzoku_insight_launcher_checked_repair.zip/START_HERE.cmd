@echo off
setlocal EnableExtensions
cd /d "%~dp0"
wscript.exe "%~dp0start_hidden.vbs"
exit /b 0
