@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title 相続インサイト 診断

echo ========================================
echo 相続インサイト 診断
echo ========================================
echo.
set "APP=%~dp0souzoku_insight_app.py"
set "DATA_DIR=%~dp0souzoku_insight_data"
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>nul
if not exist "%APP%" (
  echo [ERROR] souzoku_insight_app.py が見つかりません。ZIPをすべて展開してください。
  pause
  exit /b 1
)

call :FIND_PYTHON
if errorlevel 1 goto NO_PYTHON

echo [1] Python確認
call :RUN_PY -c "import sys; print(sys.version); raise SystemExit(0 if sys.version_info >= (3,8) else 1)"
if errorlevel 1 goto ERR

echo.
echo [2] アプリ構文確認
call :RUN_PY -m py_compile "%APP%"
if errorlevel 1 goto ERR

echo.
echo [3] 起動前診断
call :RUN_PY "%APP%" --startup-check
if errorlevel 1 goto ERR

echo.
echo [4] 検証ゲート
call :RUN_PY "%~dp0check_gate.py"
if errorlevel 1 goto ERR

echo.
echo 診断OKです。START_HERE.cmd を実行してください。
pause
exit /b 0

:FIND_PYTHON
set "PY_MODE="
set "PYTHON_EXE="
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
if not errorlevel 1 ( set "PY_MODE=PYLAUNCHER" & exit /b 0 )
for %%C in (python python3) do (
  for /f "delims=" %%P in ('where %%C 2^>nul') do (
    "%%P" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
    if not errorlevel 1 ( set "PY_MODE=PYTHON" & set "PYTHON_EXE=%%P" & exit /b 0 )
  )
)
exit /b 1

:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" ( py -3 %* ) else ( "%PYTHON_EXE%" %* )
exit /b %ERRORLEVEL%

:NO_PYTHON
echo [ERROR] Python 3.8以上が見つかりません。
echo Pythonなしで最低限開く場合は STANDALONE.html を開いてください。ただしPython連携出力は使えません。
pause
exit /b 1

:ERR
echo.
echo [ERROR] 診断で問題が出ました。上のエラー文を確認してください。
pause
exit /b 1
