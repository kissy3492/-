#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
相続インサイト補助エンジン

HTML本体から受け取った入力グリッド/解析結果を、Python側で検算・高度照合・調書素材化する。
外部ライブラリ不要。標準ライブラリだけで動作する。
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import datetime as _dt
import io
import json
import math
import os
import re
import sqlite3
import sys
import tempfile
import threading
import unicodedata
import webbrowser
import zipfile
from dataclasses import dataclass, asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlparse, parse_qs
from xml.sax.saxutils import escape as xml_escape

APP_NAME = "相続インサイト補助エンジン"
DEFAULT_PORT = 8765
MAX_POST_BYTES = 20 * 1024 * 1024
SCHEMA_VERSION = "2026-06-commercial-grade"
CASE_DB_NAME = "insight_case_db.sqlite"

TX_COLUMNS = ["銀行名","支店名","氏名","科目","口座番号","日付","時刻","出金","入金","取扱店","機番","摘要","残高"]
FAMILY_COLUMNS = ["姓","名","続柄","生年月日","相続開始日","親の氏名","婚姻日","取得区分","死亡日"]
ADDRESS_COLUMNS = ["氏名","住所","居住開始日"]

ERA_BASE = {
    "R": 2018, "令和": 2018,
    "H": 1988, "平成": 1988,
    "S": 1925, "昭和": 1925,
    "T": 1911, "大正": 1911,
    "M": 1867, "明治": 1867,
}

@dataclass
class Transaction:
    tx_id: str
    row_number: int
    bank: str
    branch: str
    name: str
    account_type: str
    account_number: str
    date: Optional[str]
    time: str
    withdrawal: Optional[int]
    deposit: Optional[int]
    store: str
    machine: str
    memo: str
    balance: Optional[int]
    raw: List[str]

    @property
    def amount_out(self) -> int:
        return int(self.withdrawal or 0)

    @property
    def amount_in(self) -> int:
        return int(self.deposit or 0)

    @property
    def account_key(self) -> str:
        return "|".join([self.bank, self.branch, self.name, self.account_type, self.account_number])

    @property
    def stable_key(self) -> str:
        """行番号に依存しない取引キー。判断保存・差分比較の衝突防止に使う。"""
        raw = "|".join([
            self.bank, self.branch, self.name, self.account_type, self.account_number,
            self.date or "", self.time or "", str(self.amount_out), str(self.amount_in),
            self.memo or "", self.store or "", self.machine or "", str(self.balance if self.balance is not None else ""),
        ])
        return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:20]

    @property
    def date_obj(self) -> Optional[_dt.date]:
        if not self.date:
            return None
        try:
            return _dt.date.fromisoformat(self.date)
        except ValueError:
            return None


def norm_text(value: Any) -> str:
    if value is None:
        return ""
    s = unicodedata.normalize("NFKC", str(value))
    return s.replace("\u3000", " ").strip()


def compact_name(value: Any) -> str:
    return re.sub(r"[\s\u3000]+", "", norm_text(value))


def parse_amount(value: Any) -> Tuple[Optional[int], Optional[str]]:
    s = norm_text(value)
    if not s:
        return None, None
    negative = False
    if s.startswith("▲") or s.startswith("△"):
        negative = True
        s = s[1:]
    if s.startswith("(") and s.endswith(")"):
        negative = True
        s = s[1:-1]
    s = s.replace(",", "").replace("円", "").replace("¥", "").replace("￥", "")
    s = re.sub(r"\s+", "", s)
    if s.startswith("-"):
        negative = True
        s = s[1:]
    if not s:
        return None, None
    if not re.fullmatch(r"\d+(?:\.0+)?", s):
        return None, f"金額として読めません: {value}"
    n = int(float(s))
    return (-n if negative else n), None


def _valid_date(y: int, m: int, d: int) -> Optional[_dt.date]:
    try:
        return _dt.date(y, m, d)
    except ValueError:
        return None


def parse_date(value: Any) -> Tuple[Optional[str], Optional[str]]:
    raw = norm_text(value)
    if not raw:
        return None, None
    s = raw.replace("年", ".").replace("月", ".").replace("日", "")
    s = s.replace("/", ".").replace("／", ".").replace("-", ".").replace("ー", ".").replace("．", ".").replace("。", ".")
    s = re.sub(r"\s+", "", s)

    m = re.fullmatch(r"([12]\d{3})\.(\d{1,2})\.(\d{1,2})", s)
    if m:
        dt = _valid_date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        if dt:
            return dt.isoformat(), None
        return None, f"実在しない日付です: {raw}"

    m = re.fullmatch(r"([12]\d{3})(\d{2})(\d{2})", s)
    if m:
        dt = _valid_date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        if dt:
            return dt.isoformat(), None
        return None, f"実在しない日付です: {raw}"

    m = re.fullmatch(r"(R|令和|H|平成|S|昭和|T|大正|M|明治)(元|\d{1,2})\.(\d{1,2})\.(\d{1,2})", s, flags=re.I)
    if m:
        era = m.group(1)
        if len(era) == 1:
            era = era.upper()
        yy = 1 if m.group(2) == "元" else int(m.group(2))
        y = ERA_BASE.get(era, 0) + yy
        dt = _valid_date(y, int(m.group(3)), int(m.group(4)))
        if dt:
            return dt.isoformat(), None
        return None, f"実在しない日付です: {raw}"

    # 6桁・8桁の照会回答崩れへの軽い対応
    m = re.fullmatch(r"(\d{6})", s)
    if m:
        n = m.group(1)
        # 300501 のような平成表記を優先
        yy, mo, dd = int(n[:2]), int(n[2:4]), int(n[4:6])
        if 1 <= yy <= 31:
            dt = _valid_date(1988 + yy, mo, dd)
            if dt:
                return dt.isoformat(), None
        dt = _valid_date(2000 + yy, mo, dd)
        if dt:
            return dt.isoformat(), None

    return None, f"日付として読めません: {raw}"


def is_valid_time_like(value: Any) -> bool:
    """時刻欄の軽量チェック。空欄は許容し、明らかに不可能な時刻だけ警告対象にする。"""
    raw = norm_text(value)
    if not raw:
        return True
    s = raw.replace("時", ":").replace("分", "").replace("秒", "")
    s = s.replace("：", ":").replace(".", ":")
    s = re.sub(r"\s+", "", s)
    h = m = None
    mt = re.fullmatch(r"(\d{1,2}):(\d{1,2})(?::\d{1,2})?", s)
    if mt:
        h, m = int(mt.group(1)), int(mt.group(2))
    elif re.fullmatch(r"\d{3,4}", s):
        if len(s) == 3:
            h, m = int(s[0]), int(s[1:])
        else:
            h, m = int(s[:2]), int(s[2:])
    elif re.fullmatch(r"\d{1,2}", s):
        h, m = int(s), 0
    else:
        return False
    return 0 <= h <= 23 and 0 <= m <= 59


def looks_like_header(row: Any, expected: Optional[List[str]] = None) -> bool:
    """グリッド先頭行がヘッダかを判定する。ヘッダなしJSONの先頭データ行を黙って捨てないため。"""
    if not isinstance(row, list):
        return False
    cells = [norm_text(c) for c in row]
    joined = "|".join(cells)
    expected = expected or []
    hits = sum(1 for x in expected if x and x in cells)
    keyword_hits = sum(1 for k in ("銀行名", "支店名", "氏名", "科目", "口座番号", "日付", "出金", "入金", "残高", "続柄", "住所", "居住開始日") if k in joined)
    return hits >= 2 or keyword_hits >= 2


def rows_from_grid(raw: Any, expected_header: Optional[List[str]] = None) -> List[List[str]]:
    if not isinstance(raw, list) or not raw:
        return []
    start = 1 if looks_like_header(raw[0], expected_header) else 0
    rows = []
    for r in raw[start:]:
        if not isinstance(r, list):
            continue
        cells = [norm_text(c) for c in r]
        if any(cells):
            rows.append(cells)
    return rows


def cell(row: List[str], idx: int) -> str:
    return row[idx] if idx < len(row) else ""


def parse_transactions(raw_grid: Any) -> Tuple[List[Transaction], List[Dict[str, Any]]]:
    txs: List[Transaction] = []
    issues: List[Dict[str, Any]] = []
    for idx, row in enumerate(rows_from_grid(raw_grid, TX_COLUMNS), start=2):
        bank = cell(row, 0)
        branch = cell(row, 1)
        name = compact_name(cell(row, 2))
        account_type = cell(row, 3)
        account_number = cell(row, 4)
        date, date_error = parse_date(cell(row, 5))
        withdrawal, werr = parse_amount(cell(row, 7))
        deposit, derr = parse_amount(cell(row, 8))
        balance, berr = parse_amount(cell(row, 12))
        tx_id = f"tx-{idx}"
        loc = f"取引 {idx}行目"
        amount_present = bool((withdrawal or 0) or (deposit or 0) or norm_text(cell(row, 7)) or norm_text(cell(row, 8)))
        if amount_present:
            missing_account_fields = []
            if not bank:
                missing_account_fields.append("銀行")
            if not branch:
                missing_account_fields.append("支店")
            if not account_number:
                missing_account_fields.append("口座番号")
            if missing_account_fields:
                issues.append(issue("warning", "口座情報", loc, f"金額が入力されていますが{'・'.join(missing_account_fields)}が空欄です。追加抽出や口座別確認で迷わないよう、分かる範囲で補完してください。", tx_id))
        if not name:
            if amount_present:
                issues.append(issue("error", "氏名", loc, "金額が入力されていますが氏名が空欄です。名義を確認するまで分析対象から外します。", tx_id))
            else:
                issues.append(issue("warning", "氏名", loc, "氏名が空欄です。名義別分析・資金移動照合の精度が落ちます。", tx_id))
        if date_error:
            issues.append(issue("error", "日付", loc, date_error, tx_id))
        if amount_present and not date and not date_error:
            issues.append(issue("error", "日付", loc, "金額が入力されていますが日付が空欄です。原票の日付を確認するまで分析対象から外します。", tx_id))
        if not is_valid_time_like(cell(row, 6)):
            issues.append(issue("warning", "時刻", loc, f"時刻として不自然です: {cell(row, 6)}。同日取引の順序確認に影響する可能性があります。", tx_id))
        for err in (werr, derr, berr):
            if err:
                issues.append(issue("error", "金額", loc, err, tx_id))
        if (withdrawal or 0) < 0:
            issues.append(issue("error", "金額", loc, "出金欄にマイナス金額があります。入出金列・符号・貼付元の形式を確認してください。", tx_id))
        if (deposit or 0) < 0:
            issues.append(issue("error", "金額", loc, "入金欄にマイナス金額があります。入出金列・符号・貼付元の形式を確認してください。", tx_id))
        if balance is not None and balance < 0:
            issues.append(issue("warning", "残高", loc, "残高がマイナスです。借越口座でない場合は読取・入力を確認してください。", tx_id))
        if (withdrawal or 0) > 0 and (deposit or 0) > 0:
            issues.append(issue("error", "入出金", loc, "同一行に出金と入金が両方入っています。照会回答の列ズレ、取消・訂正、別取引混入を確認してください。", tx_id))
        if not (withdrawal or 0) and not (deposit or 0) and balance is None:
            issues.append(issue("info", "空行候補", loc, "出金・入金・残高が空欄です。不要行なら削除候補です。", tx_id))
        txs.append(Transaction(
            tx_id=tx_id,
            row_number=idx,
            bank=bank,
            branch=branch,
            name=name,
            account_type=account_type,
            account_number=account_number,
            date=date,
            time=cell(row, 6),
            withdrawal=withdrawal if withdrawal is not None else 0,
            deposit=deposit if deposit is not None else 0,
            store=cell(row, 9),
            machine=cell(row, 10),
            memo=cell(row, 11),
            balance=balance,
            raw=row,
        ))
    return txs, issues


def analysis_excluded_tx_ids(txs: List[Transaction], issues: List[Dict[str, Any]]) -> set:
    """入力確認が必要な行を分析対象から外す。

    日付・金額エラーや入出金両方入りの行を材料に確認カードを作ると、
    入力ミスから誤った作業が発生するため、分析本体から除外する。
    """
    ids = {str(i.get("tx_id")) for i in issues if i.get("tx_id") and str(i.get("severity")) == "error"}
    for t in txs:
        if not t.date:
            ids.add(t.tx_id)
        if not t.name and (t.amount_out > 0 or t.amount_in > 0):
            ids.add(t.tx_id)
        if (t.withdrawal or 0) < 0 or (t.deposit or 0) < 0:
            ids.add(t.tx_id)
        if t.amount_out > 0 and t.amount_in > 0:
            ids.add(t.tx_id)
    # 完全重複行は、重複か同一条件の別取引かを原票で確認するまで分析材料にしない。
    by_key: Dict[str, List[Transaction]] = {}
    for t in txs:
        if t.amount_out > 0 or t.amount_in > 0:
            by_key.setdefault(t.stable_key, []).append(t)
    for rows in by_key.values():
        if len(rows) >= 2:
            ids.update(t.tx_id for t in rows)
    return ids


def filter_analysis_txs(txs: List[Transaction], excluded_ids: set) -> List[Transaction]:
    return [t for t in txs if t.tx_id not in excluded_ids]


def parse_family(raw_grid: Any) -> Dict[str, Any]:
    people = []
    deceased = ""
    inheritance_date = None
    for row in rows_from_grid(raw_grid, FAMILY_COLUMNS):
        name = compact_name(cell(row, 0) + cell(row, 1)) or compact_name(cell(row, 0))
        relation = cell(row, 2)
        inh, _ = parse_date(cell(row, 4))
        death, _ = parse_date(cell(row, 8))
        if name:
            people.append({
                "name": name,
                "relation": relation,
                "birth": parse_date(cell(row, 3))[0],
                "inheritance_date": inh,
                "parent": cell(row, 5),
                "marriage": parse_date(cell(row, 6))[0],
                "acquisition": cell(row, 7),
                "death": death,
            })
        if "被相続人" in relation or (inh and not inheritance_date):
            deceased = name or deceased
            inheritance_date = inh or inheritance_date
    return {"people": people, "deceased": deceased, "inheritance_date": inheritance_date}


def parse_addresses(raw_grid: Any) -> List[Dict[str, Any]]:
    out = []
    for row in rows_from_grid(raw_grid):
        name = compact_name(cell(row, 0))
        if not name:
            continue
        out.append({"name": name, "address": cell(row, 1), "start_date": parse_date(cell(row, 2))[0]})
    return out


def issue(severity: str, category: str, location: str, message: str, tx_id: Optional[str] = None) -> Dict[str, Any]:
    return {"severity": severity, "category": category, "location": location, "message": message, "tx_id": tx_id}


def money(n: Any) -> str:
    try:
        return f"{int(n):,}円"
    except Exception:
        return str(n)


def date_diff(a: Optional[str], b: Optional[str]) -> Optional[int]:
    if not a or not b:
        return None
    try:
        da = _dt.date.fromisoformat(a)
        db = _dt.date.fromisoformat(b)
        return abs((db - da).days)
    except ValueError:
        return None


def signed_date_diff(a: Optional[str], b: Optional[str]) -> Optional[int]:
    """b - a の日数。資金移動では出金日→入金日を厳守するために使う。"""
    if not a or not b:
        return None
    try:
        da = _dt.date.fromisoformat(a)
        db = _dt.date.fromisoformat(b)
        return (db - da).days
    except ValueError:
        return None


def add_days(date_str: Optional[str], days: int) -> str:
    if not date_str:
        return ""
    try:
        return (_dt.date.fromisoformat(date_str) + _dt.timedelta(days=days)).isoformat()
    except ValueError:
        return ""


def in_range(date_str: Optional[str], center: Optional[str], days: int) -> bool:
    d = signed_date_diff(center, date_str)
    return d is not None and abs(d) <= days


def tx_label(tx: Transaction) -> str:
    amt = tx.amount_out or tx.amount_in
    kind = "出金" if tx.amount_out else "入金"
    return f"{tx.date or '日付不明'} {tx.name or '名義不明'} {kind}{money(amt)} {tx.bank}{tx.branch} {tx.account_number} {tx.memo}"


def analyze_balance(txs: List[Transaction], mode: str = "reference") -> List[Dict[str, Any]]:
    """残高検算。一部抽出入力では主機能にせず、参考情報に落とす。"""
    if mode == "off":
        return []
    issues: List[Dict[str, Any]] = []
    by_account: Dict[str, List[Transaction]] = {}
    for tx in txs:
        by_account.setdefault(tx.account_key, []).append(tx)
    partial = mode in ("reference", "partial", "一部抽出", "一部抽出入力")
    balance_sev = "info" if partial else "warning"
    for key, rows in by_account.items():
        rows.sort(key=lambda t: ((t.date or "9999-99-99"), t.time, t.row_number))
        prev: Optional[Transaction] = None
        seen = set()
        for tx in rows:
            dup_key = (tx.date, tx.time, tx.amount_out, tx.amount_in, tx.balance, tx.memo)
            if dup_key in seen:
                issues.append(issue("warning", "重複候補", f"取引 {tx.row_number}行目", "同一口座内に日付・時刻・金額・残高・摘要が同じ取引があります。二重入力または同一明細の重複抽出を確認してください。", tx.tx_id))
            seen.add(dup_key)
            if prev and prev.balance is not None and tx.balance is not None:
                expected = prev.balance - tx.amount_out + tx.amount_in
                if expected != tx.balance:
                    if partial:
                        msg = f"抽出入力では途中行が未入力の可能性があるため、残高検算は参考扱いです。前残高 {money(prev.balance)} から見ると計算残高は {money(expected)}、入力残高は {money(tx.balance)}。原票の前後取引を追加抽出する必要があるかだけ確認してください。"
                    else:
                        msg = f"前残高 {money(prev.balance)} - 出金 {money(tx.amount_out)} + 入金 {money(tx.amount_in)} = {money(expected)} ですが、行の残高は {money(tx.balance)} です。欠落行・OCR崩れ・並び順を確認してください。"
                    issues.append(issue(balance_sev, "残高参考" if partial else "残高不一致", f"取引 {tx.row_number}行目", msg, tx.tx_id))
            prev = tx
    return issues


def get_thresholds(payload: Dict[str, Any]) -> Dict[str, int]:
    settings = payload.get("settings") or {}
    def clamp(n: int, lo: int, hi: int) -> int:
        return max(lo, min(hi, int(n)))
    def pick(*names: str, default: int, lo: int = 0, hi: int = 10**12) -> int:
        for n in names:
            if n in settings:
                val, err = parse_amount(settings[n])
                if val is not None:
                    return clamp(abs(int(val)), lo, hi)
        return clamp(default, lo, hi)
    def ipick(*names: str, default: int, lo: int = 0, hi: int = 365) -> int:
        for n in names:
            try:
                if n in settings and str(settings[n]).strip() != "":
                    return clamp(int(float(str(settings[n]).replace(',', ''))), lo, hi)
            except Exception:
                pass
        return clamp(default, lo, hi)
    return {
        "min_transfer": pick("transferMinAmount", "largeAmountThreshold", default=100_000, lo=10_000, hi=100_000_000),
        "large": pick("largeAmountThreshold", default=1_000_000, lo=10_000, hi=1_000_000_000),
        "unknown": pick("unknownSourceThreshold", default=500_000, lo=10_000, hi=1_000_000_000),
        "cash": pick("cashWithdrawalThreshold", "cashThreshold", default=1_000_000, lo=10_000, hi=1_000_000_000),
        "aggregation": pick("aggregationThreshold", "periodAggregationThreshold", default=1_000_000, lo=10_000, hi=1_000_000_000),
        "days": ipick("transferDays", "transferWindowDays", default=3, lo=0, hi=30),
        "group_days": ipick("groupTransferDays", "transferWindowDays", default=5, lo=0, hi=30),
        "bridge_days": ipick("cashBridgeDays", "bridgeDays", default=7, lo=0, hi=30),
        "period_days": ipick("periodAggregationDays", default=30, lo=1, hi=180),
        "pre_death_days": ipick("preDeathDays", "inheritanceFocusDays", default=90, lo=1, hi=365),
        "extraction_days": ipick("extractionDays", default=30, lo=1, hi=365),
    }


def score_pair(w: Transaction, d: Transaction, deceased: str, days_window: int) -> Tuple[int, List[str]]:
    reasons = []
    diff = abs(w.amount_out - d.amount_in)
    base = max(w.amount_out, d.amount_in, 1)
    ratio = diff / base
    dd = date_diff(w.date, d.date)
    score = 100
    if dd is None:
        score -= 20
    else:
        score -= min(35, dd * 8)
        if dd == 0:
            reasons.append("同日")
        elif dd <= days_window:
            reasons.append(f"{dd}日差")
    score -= min(45, int(ratio * 100))
    if diff == 0:
        reasons.append("同額")
    elif ratio <= 0.01:
        reasons.append("金額差1%以内")
    elif ratio <= 0.05:
        reasons.append("金額差5%以内")
    if w.name and d.name and w.name != d.name:
        reasons.append("名義差あり")
    else:
        score -= 8
        reasons.append("同一名義")
    if deceased and (w.name == deceased or d.name == deceased):
        score += 8
        reasons.append("被相続人関与")
    if w.account_key == d.account_key:
        score -= 45
        reasons.append("同一口座内")
    if "振替" in w.memo or "振替" in d.memo:
        reasons.append("摘要に振替")
    return max(0, min(100, score)), reasons


def find_transfers(txs: List[Transaction], family: Dict[str, Any], th: Dict[str, int]) -> List[Dict[str, Any]]:
    withdrawals = [t for t in txs if t.amount_out >= th["min_transfer"] and t.date]
    deposits = [t for t in txs if t.amount_in >= th["min_transfer"] and t.date]
    deceased = family.get("deceased") or ""
    out: List[Dict[str, Any]] = []
    for w in withdrawals:
        for d in deposits:
            if w.tx_id == d.tx_id:
                continue
            # 同一口座内の出入金は資金移動候補から除外する。
            # 入力確認・取消訂正等の確認対象であり、名義間移動として上位表示しない。
            if w.account_key == d.account_key:
                continue
            dd = signed_date_diff(w.date, d.date)
            if dd is None or dd < 0 or dd > th["days"]:
                continue
            diff = abs(w.amount_out - d.amount_in)
            tol = max(10_000, int(max(w.amount_out, d.amount_in) * 0.05))
            if diff > tol:
                continue
            score, reasons = score_pair(w, d, deceased, th["days"])
            if score < 45:
                continue
            out.append({
                "score": score,
                "from": f"{w.date} {w.name} {w.bank}{w.branch} {w.account_number}",
                "to": f"{d.date} {d.name} {d.bank}{d.branch} {d.account_number}",
                "from_tx_id": w.tx_id,
                "to_tx_id": d.tx_id,
                "withdrawal": w.amount_out,
                "deposit": d.amount_in,
                "amount_diff": diff,
                "days_diff": dd,
                "reasons": reasons,
            })
    out.sort(key=lambda x: (-x["score"], x["days_diff"], x["amount_diff"]))
    return out[:300]


def find_same_account_offsets(txs: List[Transaction], th: Dict[str, int]) -> List[Dict[str, Any]]:
    """同一口座・同日・近似額の出入金。資金移動等ではなく、入力確認へ寄せる。"""
    by: Dict[Tuple[str, str], Dict[str, List[Transaction]]] = {}
    for t in txs:
        if not t.date:
            continue
        key = (t.account_key, t.date)
        bucket = by.setdefault(key, {"out": [], "in": []})
        if t.amount_out > 0:
            bucket["out"].append(t)
        if t.amount_in > 0:
            bucket["in"].append(t)
    rows: List[Dict[str, Any]] = []
    seen = set()
    for (account_key, date), bucket in by.items():
        for w in bucket["out"]:
            for d in bucket["in"]:
                if w.tx_id == d.tx_id:
                    continue
                amount = max(w.amount_out, d.amount_in)
                if amount <= 0:
                    continue
                diff = abs(w.amount_out - d.amount_in)
                tol = max(1_000, int(amount * 0.01))
                if diff > tol:
                    continue
                k = tuple(sorted([w.stable_key, d.stable_key]))
                if k in seen:
                    continue
                seen.add(k)
                rows.append({
                    "account_key": account_key,
                    "date": date,
                    "name": w.name or d.name,
                    "bank": w.bank or d.bank,
                    "branch": w.branch or d.branch,
                    "account_type": w.account_type or d.account_type,
                    "account_number": w.account_number or d.account_number,
                    "amount": amount,
                    "amount_diff": diff,
                    "withdrawal_tx_id": w.tx_id,
                    "deposit_tx_id": d.tx_id,
                    "tx_ids": [w.tx_id, d.tx_id],
                    "tx_stable_keys": [w.stable_key, d.stable_key],
                    "message": "同一口座内で同日・近似額の出金と入金があります。まず原票で、取消・訂正・入力列・別取引混入を確認してください。",
                })
    return sorted(rows, key=lambda r: (r.get("date") or "", -int(r.get("amount") or 0)))[:120]


def find_group_transfers(txs: List[Transaction], family: Dict[str, Any], th: Dict[str, int]) -> List[Dict[str, Any]]:
    withdrawals = [t for t in txs if t.amount_out >= max(30_000, th["min_transfer"] // 3) and t.date]
    deposits = [t for t in txs if t.amount_in >= max(30_000, th["min_transfer"] // 3) and t.date]
    out: List[Dict[str, Any]] = []

    def close_dates(items: List[Transaction]) -> bool:
        dates = [x.date_obj for x in items if x.date_obj]
        return bool(dates) and (max(dates) - min(dates)).days <= th["group_days"]

    # 1出金→複数入金
    for w in withdrawals:
        cands = [d for d in deposits if d.tx_id != w.tx_id and signed_date_diff(w.date, d.date) is not None and 0 <= signed_date_diff(w.date, d.date) <= th["group_days"] and d.account_key != w.account_key]
        for r in (2, 3):
            for ds in combinations(cands[:18], r):
                if not close_dates([w] + list(ds)):
                    continue
                total = sum(d.amount_in for d in ds)
                diff = abs(w.amount_out - total)
                if diff <= max(20_000, int(w.amount_out * 0.05)):
                    names = "、".join(sorted({d.name for d in ds if d.name}))
                    out.append({
                        "score": max(50, 92 - int(diff / max(w.amount_out, 1) * 100)),
                        "kind": "1→複数",
                        "from": f"{w.date} {w.name}",
                        "to": names,
                        "from_tx_ids": [w.tx_id],
                        "to_tx_ids": [d.tx_id for d in ds],
                        "withdrawal_total": w.amount_out,
                        "deposit_total": total,
                        "amount_diff": diff,
                        "reasons": ["分割入金候補", f"{len(ds)}件合算", f"{th['group_days']}日内"],
                    })
    # 複数出金→1入金
    for d in deposits:
        cands = [w for w in withdrawals if w.tx_id != d.tx_id and signed_date_diff(w.date, d.date) is not None and 0 <= signed_date_diff(w.date, d.date) <= th["group_days"] and w.account_key != d.account_key]
        for r in (2, 3):
            for ws in combinations(cands[:18], r):
                if not close_dates([d] + list(ws)):
                    continue
                total = sum(w.amount_out for w in ws)
                diff = abs(total - d.amount_in)
                if diff <= max(20_000, int(d.amount_in * 0.05)):
                    names = "、".join(sorted({w.name for w in ws if w.name}))
                    out.append({
                        "score": max(50, 92 - int(diff / max(d.amount_in, 1) * 100)),
                        "kind": "複数→1",
                        "from": names,
                        "to": f"{d.date} {d.name}",
                        "from_tx_ids": [w.tx_id for w in ws],
                        "to_tx_ids": [d.tx_id],
                        "withdrawal_total": total,
                        "deposit_total": d.amount_in,
                        "amount_diff": diff,
                        "reasons": ["合算入金候補", f"{len(ws)}件合算", f"{th['group_days']}日内"],
                    })
    # 重複気味の候補を軽く間引く
    seen = set()
    uniq = []
    for x in sorted(out, key=lambda a: (-a["score"], a["amount_diff"])):
        key = (tuple(sorted(x.get("from_tx_ids", []))), tuple(sorted(x.get("to_tx_ids", []))))
        if key in seen:
            continue
        seen.add(key)
        uniq.append(x)
    return uniq[:120]


def find_near_thresholds(txs: List[Transaction]) -> List[Dict[str, Any]]:
    thresholds = [1_000_000, 1_100_000, 3_000_000, 5_000_000, 10_000_000]
    out = []
    for tx in txs:
        for kind, amount in (("出金", tx.amount_out), ("入金", tx.amount_in)):
            if amount <= 0:
                continue
            for th in thresholds:
                if amount == th:
                    band = "節目額ちょうど"
                elif int(th * 0.95) <= amount < th:
                    band = "節目額直下"
                elif int(th * 0.90) <= amount < int(th * 0.95):
                    band = "節目額付近"
                else:
                    continue
                out.append({
                    "date": tx.date,
                    "name": tx.name,
                    "tx_id": tx.tx_id,
                    "kind": kind,
                    "amount": amount,
                    "threshold": th,
                    "band": band,
                    "message": f"{money(th)}の{band}に当たる{kind}。分散・贈与・現金化・通常取引のいずれかを確認。",
                })
                break
    out.sort(key=lambda x: (x["threshold"], -x["amount"]))
    return out[:200]


def find_annual_patterns(transfers: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_pair: Dict[str, List[Dict[str, Any]]] = {}
    for t in transfers:
        pair = f"{t.get('from','').split(' ')[1] if t.get('from') else ''} → {t.get('to','').split(' ')[1] if t.get('to') else ''}"
        by_pair.setdefault(pair, []).append(t)
    out = []
    for pair, rows in by_pair.items():
        years: Dict[str, int] = {}
        amounts = []
        for r in rows:
            text = str(r.get("from", ""))
            m = re.search(r"(\d{4})-", text)
            if not m:
                continue
            years[m.group(1)] = years.get(m.group(1), 0) + 1
            amounts.append(int(r.get("deposit") or r.get("withdrawal") or 0))
        if len(years) >= 2 and amounts:
            amounts_sorted = sorted(amounts)
            typical = amounts_sorted[len(amounts_sorted)//2]
            total = sum(amounts)
            out.append({
                "pair": pair,
                "years": "、".join(sorted(years.keys())),
                "typical_amount": typical,
                "total_amount": total,
                "message": "複数年にわたり近接した資金移動候補があります。贈与・生活費・預け金の整理対象。",
            })
    return sorted(out, key=lambda x: -x["total_amount"])[:80]


def find_unknown_sources(txs: List[Transaction], transfers: List[Dict[str, Any]], threshold: int) -> List[Dict[str, Any]]:
    matched_deposits = {t.get("to_tx_id") for t in transfers}
    out = []
    ordinary_income_words = ("給与", "賞与", "年金", "利息", "配当", "振込給与")
    asset_income_words = ("保険", "還付", "売却", "解約", "満期", "給付", "証券", "不動産", "定期")
    for tx in txs:
        if tx.amount_in < threshold or tx.tx_id in matched_deposits:
            continue
        memo = tx.memo or ""
        if any(w in memo for w in ordinary_income_words):
            cls = "通常収入系・低優先"
            pri = "低"
            msg = "摘要に給与・年金等の説明語があります。原資不明と断定せず、金額・時期が不自然な場合だけ確認。"
        elif any(w in memo for w in asset_income_words):
            cls = "資産換価・保険等の確認"
            pri = "中"
            msg = "摘要に保険・売却・解約・満期等の説明語があります。原資不明ではなく、支払通知・売買契約・解約計算書等で確認。"
        elif memo.strip():
            cls = "説明語あり・確認候補"
            pri = "中"
            msg = "摘要はありますが、原資を説明し切れるかは未確認です。前後明細と資料で確認。"
        else:
            cls = "原資不明"
            pri = "高"
            msg = "摘要空欄または説明不足の大口入金です。現入力範囲では近接する対応出金候補が見当たりません。"
        out.append({
            "date": tx.date,
            "name": tx.name,
            "tx_id": tx.tx_id,
            "amount": tx.amount_in,
            "memo": tx.memo,
            "source_class": cls,
            "priority": pri,
            "message": msg,
        })
    priority_order = {"高": 0, "中": 1, "低": 2}
    return sorted(out, key=lambda x: (priority_order.get(x.get("priority", "中"), 1), -x["amount"]))[:200]


CASH_WORDS = ("現金", "ＡＴＭ", "ATM", "払戻", "払戻し", "払出", "窓口", "出金")
EXPLAINED_INCOME_WORDS = ("給与", "賞与", "年金", "利息", "配当", "保険", "還付", "売却", "解約", "満期", "給付", "振込給与")
MEDICAL_LIFE_WORDS = ("医療", "病院", "介護", "施設", "老人", "葬儀", "税金", "生活", "家賃", "光熱", "公共料金")
ASSET_WORDS = ("証券", "株", "投信", "不動産", "保険", "定期", "解約", "売却", "満期")
LOAN_GIFT_WORDS = ("贈与", "貸付", "借入", "返済", "立替", "預け", "預り", "名義")


def extraction_profile(txs: List[Transaction], family: Dict[str, Any], addresses: List[Dict[str, Any]], mode: str) -> Dict[str, Any]:
    dates = [t.date for t in txs if t.date]
    names = sorted({t.name for t in txs if t.name})
    family_names = sorted({p.get("name") for p in family.get("people", []) if p.get("name")})
    tx_name_set = set(names)
    fam_set = set(family_names)
    balance_rate = round(sum(1 for t in txs if t.balance is not None) / max(1, len(txs)) * 100, 1)
    return {
        "input_mode": mode,
        "transaction_count": len(txs),
        "name_count": len(names),
        "account_count": len({t.account_key for t in txs}),
        "date_start": min(dates) if dates else "",
        "date_end": max(dates) if dates else "",
        "balance_input_rate": balance_rate,
        "family_without_transactions": sorted(fam_set - tx_name_set),
        "transaction_names_not_in_family": sorted(tx_name_set - fam_set),
        "address_count": len(addresses),
        "note": "一部抽出入力では、未検出は不存在ではなく、現入力範囲では確認できないという意味です。"
    }


def quality_gates(profile: Dict[str, Any], family: Dict[str, Any]) -> List[Dict[str, Any]]:
    gates=[]
    def add(level, item, message):
        gates.append({"level": level, "item": item, "message": message})
    if profile.get("transaction_count",0) < 5:
        add("warning", "取引件数", "入力取引が少ないため、候補は限定的です。重要行だけの抽出であれば、追加抽出カードを優先してください。")
    if not family.get("deceased"):
        add("warning", "被相続人", "家族情報から被相続人を特定できません。続柄欄に『被相続人』を入れると分析精度が上がります。")
    if not family.get("inheritance_date"):
        add("warning", "相続開始日", "相続開始日が未設定です。死亡日前後集中・直前現金化の優先度判定が弱くなります。")
    if profile.get("family_without_transactions"):
        add("info", "家族未入力", "家族情報にあるが取引未入力の人物があります: " + "、".join(profile["family_without_transactions"][:10]))
    if profile.get("transaction_names_not_in_family"):
        add("warning", "関係者整理", "取引にはあるが家族情報にない名義があります: " + "、".join(profile["transaction_names_not_in_family"][:10]))
    if not gates:
        add("ok", "前提", "主要な分析前提に大きな不足は検出されませんでした。")
    return gates


def memo_signals(txs: List[Transaction]) -> List[Dict[str, Any]]:
    out=[]
    for t in txs:
        text=t.memo or ""
        cats=[]
        if not text.strip(): cats.append("摘要空欄")
        if any(w in text for w in CASH_WORDS): cats.append("現金/ATM/窓口")
        if any(w in text for w in EXPLAINED_INCOME_WORDS): cats.append("説明語あり")
        if any(w in text for w in MEDICAL_LIFE_WORDS): cats.append("生活/医療介護/葬儀")
        if any(w in text for w in ASSET_WORDS): cats.append("資産換価/金融商品")
        if any(w in text for w in LOAN_GIFT_WORDS): cats.append("贈与/貸付/預け金語")
        if cats:
            out.append({"tx_id": t.tx_id, "date": t.date, "name": t.name, "amount": t.amount_out or t.amount_in, "kind": "出金" if t.amount_out else "入金", "memo": text, "signals": cats})
    return out[:500]


def find_cash_withdrawals(txs: List[Transaction], th: Dict[str, int]) -> List[Dict[str, Any]]:
    out=[]
    deposits=[d for d in txs if d.amount_in>0 and d.date]
    for w in txs:
        if not w.date or w.amount_out < th["cash"]:
            continue
        cashish = any(x in (w.memo or "") for x in CASH_WORDS) or not (w.memo or "").strip()
        if not cashish:
            continue
        near=[]
        for d in deposits:
            if d.account_key == w.account_key: continue
            dd=signed_date_diff(w.date, d.date)
            if dd is not None and 0 <= dd <= th["bridge_days"]:
                ratio=abs(w.amount_out-d.amount_in)/max(w.amount_out, d.amount_in, 1)
                if ratio <= 0.15:
                    near.append({"to_tx_id": d.tx_id, "to": tx_label(d), "deposit": d.amount_in, "days_diff": dd, "amount_diff": abs(w.amount_out-d.amount_in)})
        out.append({"tx_id": w.tx_id, "date": w.date, "name": w.name, "amount": w.amount_out, "memo": w.memo, "store": w.store, "machine": w.machine, "near_deposits": near[:5], "message": "大口現金/ATM/窓口出金。使途、手許現金、交付先、近接する家族口座入金を確認。"})
    return sorted(out, key=lambda x: -x["amount"])[:200]


def find_period_aggregations(txs: List[Transaction], th: Dict[str, int]) -> List[Dict[str, Any]]:
    rows=[t for t in txs if t.date and (t.amount_out or t.amount_in)]
    out=[]
    for direction in ("出金","入金"):
        for name in sorted({t.name for t in rows if t.name}):
            arr=[t for t in rows if t.name==name and ((direction=="出金" and t.amount_out>0) or (direction=="入金" and t.amount_in>0))]
            arr.sort(key=lambda t:t.date or "")
            for i,t in enumerate(arr):
                bucket=[]
                for u in arr[i:]:
                    dd=signed_date_diff(t.date,u.date)
                    if dd is None or dd<0: continue
                    if dd>th["period_days"]: break
                    bucket.append(u)
                if len(bucket)>=2:
                    total=sum(x.amount_out if direction=="出金" else x.amount_in for x in bucket)
                    if total>=th["aggregation"]:
                        ids=tuple(x.tx_id for x in bucket)
                        out.append({"name":name,"kind":direction,"start_date":bucket[0].date,"end_date":bucket[-1].date,"count":len(bucket),"total":total,"tx_ids":list(ids),"tx_key_set":set(ids),"message":f"{th['period_days']}日内に{direction}が{len(bucket)}件、合計{money(total)}。小口分散・期間集約として確認。"})
    # 同一名義・同一方向で取引集合が包含される小さい候補は親候補へ統合して落とす
    out_sorted = sorted(out, key=lambda r: (-len(r["tx_key_set"]), -r["total"], r["start_date"] or ""))
    kept=[]
    for cand in out_sorted:
        cset=cand["tx_key_set"]
        contained=False
        for k in kept:
            if cand["name"]==k["name"] and cand["kind"]==k["kind"] and cset and cset.issubset(k["tx_key_set"]):
                contained=True
                break
        if not contained:
            kept.append(cand)
    for x in kept:
        x.pop("tx_key_set", None)
    return sorted(kept, key=lambda r:(-r["total"], r["start_date"] or ""))[:100]


def find_timing_clusters(txs: List[Transaction], family: Dict[str, Any], addresses: List[Dict[str, Any]], th: Dict[str, int]) -> List[Dict[str, Any]]:
    centers=[]
    if family.get("inheritance_date"):
        centers.append(("相続開始日", family.get("inheritance_date"), family.get("deceased") or ""))
    for a in addresses:
        if a.get("start_date"):
            centers.append(("住所/居住イベント", a.get("start_date"), a.get("name") or ""))
    out=[]
    for label,center,person in centers:
        hits=[]
        for t in txs:
            if not t.date: continue
            amt=t.amount_out or t.amount_in
            if amt < th["large"]//2: continue
            dd=signed_date_diff(center,t.date)
            if dd is not None and abs(dd)<=th["pre_death_days"]:
                hits.append({"tx_id":t.tx_id,"date":t.date,"name":t.name,"kind":"出金" if t.amount_out else "入金","amount":amt,"days_from_center":dd,"memo":t.memo})
        if hits:
            out.append({"event":label,"center_date":center,"person":person,"count":len(hits),"total":sum(h["amount"] for h in hits),"hits":hits[:20],"message":f"{label}前後{th['pre_death_days']}日内に大口取引が集中。節目周辺の資金移動・現金化・費消を確認。"})
    return sorted(out,key=lambda x:-x["total"])[:100]


def build_person_summaries(txs: List[Transaction], transfers: List[Dict[str,Any]], cards: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    names=sorted({t.name for t in txs if t.name} | {c.get("person","") for c in cards if c.get("person")})
    out=[]
    for n in names:
        person_txs=[t for t in txs if t.name==n]
        related=[c for c in cards if c.get("person")==n or n in str(c.get("target", ""))]
        out.append({"name":n,"transaction_count":len(person_txs),"deposit_total":sum(t.amount_in for t in person_txs),"withdrawal_total":sum(t.amount_out for t in person_txs),"priority_card_count":len(related),"max_action_score":max([c.get("action_score",0) for c in related] or [0]),"top_issue":" / ".join([c.get("title","") for c in related[:3]]),"next_action":related[0].get("next_action","") if related else "現時点では上位確認カードなし"})
    return sorted(out,key=lambda r:(-r["max_action_score"],-r["priority_card_count"],r["name"]))


def risk_evidence_action(base:int, facts:List[str], missing:List[str], amount:int, has_direct_pair:bool=False) -> Tuple[int,int,int,int]:
    """risk=怪しさ、internal=入力済み事実同士の整合、doc=資料充足、action=次に見る優先度。"""
    risk=min(100, max(0, base + (10 if amount>=1_000_000 else 0) + (8 if amount>=5_000_000 else 0)))
    internal=min(100, 20 + len(facts)*12 + (20 if has_direct_pair else 0) - len(missing)*8)
    # 初期状態では外部証憑は未確認。一部抽出入力なので高く見せない。
    doc=max(0, min(35, 8 + len([m for m in missing if m])*0))
    action=min(100, int(risk*0.55 + (100-internal)*0.20 + (100-doc)*0.10 + (20 if amount>=1_000_000 else 0)))
    return risk, max(0,internal), max(0,action), doc


def build_priority_cards(result: Dict[str,Any], txs: List[Transaction], family: Dict[str,Any], th: Dict[str,int]) -> List[Dict[str,Any]]:
    txmap={t.tx_id:t for t in txs}
    same_account_offset_ids = set(result.get("same_account_offset_tx_ids") or [])
    cards=[]
    def add(category,title,person,amount,tx_ids,facts,missing,hypothesis,next_action,question,documents,base=60,target=""):
        risk,internal,action,doc=risk_evidence_action(base,facts,missing,amount,has_direct_pair=(len(tx_ids)>=2))
        dates=[txmap[i].date for i in tx_ids if i in txmap and txmap[i].date]
        center=min(dates) if dates else ""
        tx_keys=[txmap[i].stable_key for i in tx_ids if i in txmap]
        accounts=sorted({txmap[i].account_key for i in tx_ids if i in txmap})
        stores=sorted({txmap[i].store for i in tx_ids if i in txmap and txmap[i].store})
        machines=sorted({txmap[i].machine for i in tx_ids if i in txmap and txmap[i].machine})
        cards.append({"card_id":f"PC-{len(cards)+1:04d}","category":category,"title":title,"person":person,"target":target or person,"amount":amount,"risk_score":risk,"internal_consistency_score":internal,"evidence_score":internal,"document_evidence_score":doc,"action_score":action,"priority_score":int(action*0.5+risk*0.35+internal*0.15),"score_help":"確認優先度=先に見る度合い、材料=入力済み取引同士のつながり、資料=外部資料の確認状況、対応順=次に処理する順番。資料は初期状態では低く出します。","plain_summary":"このカードは確認順を示すものです。結論ではありません。まず「次にやること」を確認してください。","hypothesis":hypothesis,"supporting_facts":facts,"missing_facts":missing,"next_action":next_action,"question":question,"documents":documents,"tx_ids":tx_ids,"tx_stable_keys":tx_keys,"account_keys":accounts,"stores":stores,"machines":machines,"date":center,"extraction_from":add_days(center,-th["extraction_days"]),"extraction_to":add_days(center,th["extraction_days"]),"caution":"確認優先度であり、課税判断や証拠評価の結論ではありません。抽出入力では未検出は不存在を意味しません。"})
    for t in result.get("transfers",[])[:80]:
        tx_ids=[t.get("from_tx_id"),t.get("to_tx_id")]
        person=str(t.get("to","")).split(" ")[1] if len(str(t.get("to","")).split(" "))>1 else ""
        add("資金移動", "近接・近似額の資金移動候補", person, int(t.get("deposit") or t.get("withdrawal") or 0), [x for x in tx_ids if x], ["出金日→入金日の時系列", f"日数差{t.get('days_diff')}日", f"差額{money(t.get('amount_diff'))}"] + list(t.get("reasons") or []), ["相手方口座の前後明細", "贈与・貸付・預け金・生活費等の趣旨資料"], "贈与・貸付・預け金・名義財産・生活費移転", "対象取引の前後明細と相手方口座の同日前後を追加抽出。資金の帰属と趣旨を確認。", "この出金と入金の関係、資金の帰属、贈与・貸付・生活費・立替精算のいずれかを説明できますか。", ["相手方通帳", "贈与契約書", "贈与税申告書", "金銭消費貸借契約書", "返済記録", "生活費・立替資料"], 75, f"{t.get('from')} → {t.get('to')}")
    for x in result.get("cash_withdrawals",[])[:60]:
        if x.get("tx_id") in same_account_offset_ids:
            continue
        add("現金化", "大口現金/ATM/窓口出金", x.get("name",""), int(x.get("amount") or 0), [x.get("tx_id")], ["現金・ATM・窓口または摘要空欄", f"出金額{money(x.get('amount'))}"] + (["近接入金候補あり"] if x.get("near_deposits") else []), ["領収証・使途資料", "手許現金の残額", "交付先の有無", "出金後の家族口座入金"], "現金保管・費消・家族への交付・医療介護費", "出金日前後の明細、領収証、現金残、交付先を確認。", "この現金出金の使途、保管者、使用時期、領収証の有無を説明できますか。", ["領収証", "現金出納メモ", "医療介護費資料", "葬儀費資料", "家族口座明細"], 70)
    for x in result.get("unknown_sources",[])[:60]:
        if x.get("tx_id") in same_account_offset_ids:
            continue
        cls=x.get("source_class") or "原資確認"
        # 給与・年金等の通常収入は詳細資料には残すが、上位カード・作業キューには載せない。
        # 画面が不要な確認作業を増やさないようにする。
        if cls == "通常収入系・低優先" or x.get("priority") == "低":
            continue
        title = "大口入金の原資確認候補" if cls == "原資不明" else f"{cls}の資料確認"
        base = 66 if cls == "原資不明" else 54 if x.get("priority") == "中" else 35
        add("入金原資", title, x.get("name",""), int(x.get("amount") or 0), [x.get("tx_id")], ["大口入金", cls, x.get("message","")], ["入金の説明資料", "入金前後の明細"], "入金原資・資産換価・保険金・借入・贈与", "入金の説明資料と前後明細を確認。通常収入と読める入金は上位表示しません。", "この入金のお金はどこから来たものですか。保険金、売却代金、借入、贈与、自己資金のいずれですか。", ["保険金支払通知", "売買契約書", "解約計算書", "借入契約書", "入金前後通帳"], base)
    for x in result.get("period_aggregations",[])[:50]:
        add("小口集約", "期間内の小口集約候補", x.get("name",""), int(x.get("total") or 0), x.get("tx_ids") or [], [f"{x.get('count')}件合計{money(x.get('total'))}", f"{x.get('start_date')}〜{x.get('end_date')}"] , ["各取引の相手先・摘要・操作場所", "同一目的か偶然か"], "小口分散・連続贈与・生活費・費消", "期間内の全取引を拾い、摘要・取扱店・機番・相手先を比較。", "この期間に複数回に分かれた取引は同じ目的ですか。分けた理由はありますか。", ["期間内通帳", "取扱店/機番", "領収証", "契約書"], 58)
    deceased_name = family.get("deceased") or ""
    for x in result.get("near_thresholds",[])[:40]:
        if x.get("tx_id") in same_account_offset_ids:
            continue
        band=x.get("band") or "節目額付近"
        tx = txmap.get(x.get("tx_id"))
        memo = (tx.memo if tx else "") or ""
        is_cash_like = any(w in memo for w in CASH_WORDS) or not memo.strip()
        is_deceased = bool(deceased_name and x.get("name") == deceased_name)
        # 節目額だけで上位カードを増やさない。金額が大きい、被相続人関与、摘要空欄/現金系など、
        # 追加材料があるものだけカード化し、単独の節目額は詳細表へ回す。
        if band == "節目額付近" and not (is_cash_like or is_deceased or int(x.get("amount") or 0) >= 3_000_000):
            continue
        if not (is_cash_like or is_deceased or int(x.get("amount") or 0) >= 3_000_000):
            continue
        base = 50 if band == "節目額付近" else 58
        add("節目額", band + "の取引", x.get("name",""), int(x.get("amount") or 0), [x.get("tx_id")], [f"{money(x.get('threshold'))}{band}", x.get("kind","")] + (["摘要空欄または現金系"] if is_cash_like else []) + (["被相続人関与"] if is_deceased else []), ["分散・贈与・現金化の趣旨", "前後の類似取引"], "贈与・分散・現金化・通常取引", "前後の同種取引と相手先を確認。単独の節目額だけで判断しない。", "この金額になった理由、同時期の類似取引、贈与税申告の有無を説明できますか。", ["前後明細", "贈与税申告書", "契約書"], base)
    cards.sort(key=lambda c:(-c["priority_score"],-c["action_score"],-c["amount"]))
    cards = cards[:120]
    for i, c in enumerate(cards, 1):
        c["card_id"] = f"PC-{i:04d}"
        c["card_key"] = card_signature(c)
        c.setdefault("review_status", "未確認")
        c.setdefault("review_memo", "")
    return cards


def _split_account_key(key: str) -> Dict[str, str]:
    parts = str(key or "").split("|")
    while len(parts) < 5:
        parts.append("")
    return {"bank": parts[0], "branch": parts[1], "name": parts[2], "account_type": parts[3], "account_number": parts[4]}


def build_extraction_cards(cards: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    out=[]
    for c in cards[:60]:
        account_keys = c.get("account_keys") or []
        if not account_keys:
            account_keys = [""]
        for idx, ak in enumerate(account_keys, 1):
            a = _split_account_key(ak)
            bank_branch = (a.get("bank") or "") + (a.get("branch") or "")
            target_label = " / ".join([x for x in [a.get("name"), bank_branch, a.get("account_type"), a.get("account_number")] if x]) or c.get("target")
            out.append({
                "task_id":"EX-"+c["card_id"].split("-")[-1]+(f"-{idx}" if len(account_keys)>1 else ""),
                "priority":c.get("action_score"),
                "target":target_label,
                "person": a.get("name") or c.get("person") or c.get("target"),
                "bank": a.get("bank"),
                "branch": a.get("branch"),
                "account_type": a.get("account_type"),
                "account_number": a.get("account_number"),
                "account_ref": ak or str(c.get("target") or "対象未整理"),
                "range_from":c.get("extraction_from"),
                "range_to":c.get("extraction_to"),
                "pick_fields":"日付、時刻、出金、入金、摘要、取扱店、機番、残高、相手方表示、伝票番号があれば伝票番号",
                "purpose":c.get("next_action"),
                "linked_card":c.get("card_id")
            })
    return out

def build_questionnaires(cards: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    by={}
    for c in cards:
        p=c.get("person") or "関係者"
        by.setdefault(p,[]).append(c)
    out=[]
    for p,rows in by.items():
        qs=[]; docs=[]
        for c in rows[:8]:
            qs.append(f"【{c.get('category')}】{c.get('question')}")
            docs += c.get("documents") or []
        out.append({"person":p,"risk_count":len(rows),"max_action_score":max(r.get("action_score",0) for r in rows),"questions":qs,"documents":sorted(set(docs))})
    return sorted(out,key=lambda r:(-r["max_action_score"],-r["risk_count"]))


def build_fact_matrix(cards: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    return [{"card_id":c.get("card_id"),"category":c.get("category"),"target":c.get("target"),"known_facts":" / ".join(c.get("supporting_facts") or []),"missing_facts":" / ".join(c.get("missing_facts") or []),"hypothesis":c.get("hypothesis"),"rebuttal_test":"不足資料が提示され、生活費・貸付返済・本人管理・正当な換価収入として整合すれば、当該仮説は弱まります。","next_action":c.get("next_action")} for c in cards[:100]]


def build_brief(result: Dict[str,Any], cards: List[Dict[str,Any]], profile: Dict[str,Any], gates: List[Dict[str,Any]]) -> Dict[str,Any]:
    top=cards[:5]
    return {"headline":"抽出入力前提の確認優先度ブリーフ", "summary":[f"入力取引 {profile.get('transaction_count')}件、名義 {profile.get('name_count')}名。", f"優先確認カード {len(cards)}件。上位は {', '.join([c.get('category','') for c in top]) or 'なし'}。", "未検出は不存在ではなく、現入力範囲では確認できないという扱いです。"], "first_actions":[c.get("next_action") for c in top[:3]], "warnings":[g.get("message") for g in gates if g.get("level") in ("warning","error")][:5]}


def card_signature(card: Dict[str, Any]) -> str:
    # tx_stable_keys を最優先する。行番号由来の tx_id は、取引追加・並べ替えで変わるため、
    # stable_key がある場合は署名材料から外す。
    stable_keys = sorted(card.get("tx_stable_keys") or [])
    tx_ids_fallback = [] if stable_keys else sorted(card.get("tx_ids") or [])
    raw_obj = {
        "category": card.get("category", ""),
        "target": card.get("target", ""),
        "title": card.get("title", ""),
        "amount": card.get("amount", ""),
        "date": card.get("date", ""),
        "tx_stable_keys": stable_keys,
        "tx_ids_fallback": tx_ids_fallback,
        "account_keys": sorted(card.get("account_keys") or []),
        "stores": sorted(card.get("stores") or []),
        "machines": sorted(card.get("machines") or []),
    }
    raw = json.dumps(raw_obj, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:20]

def stable_json_hash(obj: Any) -> str:
    text = json.dumps(obj, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def build_card_bundles(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for c in cards:
        key = (str(c.get("target") or c.get("person") or "関係者"), str(c.get("category") or "未分類"))
        groups.setdefault(key, []).append(c)
    out = []
    for (target, category), rows in groups.items():
        rows = sorted(rows, key=lambda c: (-int(c.get("action_score") or 0), -int(c.get("amount") or 0)))
        docs = sorted({d for c in rows for d in (c.get("documents") or []) if d})
        missing = sorted({m for c in rows for m in (c.get("missing_facts") or []) if m})
        actions = []
        for c in rows:
            a = c.get("next_action")
            if a and a not in actions:
                actions.append(a)
        out.append({
            "bundle_id": f"BD-{len(out)+1:04d}",
            "target": target,
            "category": category,
            "card_count": len(rows),
            "total_amount": sum(int(c.get("amount") or 0) for c in rows),
            "max_risk_score": max(int(c.get("risk_score") or 0) for c in rows),
            "max_evidence_score": max(int(c.get("evidence_score") or 0) for c in rows),
            "max_action_score": max(int(c.get("action_score") or 0) for c in rows),
            "top_cards": ", ".join(c.get("card_id", "") for c in rows[:5]),
            "main_hypothesis": rows[0].get("hypothesis", "") if rows else "",
            "missing_facts": " / ".join(missing[:8]),
            "documents": " / ".join(docs[:10]),
            "next_actions": " / ".join(actions[:5]),
        })
    return sorted(out, key=lambda r: (-r["max_action_score"], -r["total_amount"], r["target"]))[:100]


def build_evidence_gap_ranking(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    gaps: Dict[str, Dict[str, Any]] = {}
    for c in cards:
        refs = [x for x in (c.get("missing_facts") or [])] + [f"必要資料:{x}" for x in (c.get("documents") or [])]
        for g in refs:
            if not g:
                continue
            row = gaps.setdefault(g, {"gap": g, "card_count": 0, "max_action_score": 0, "total_amount": 0, "linked_cards": []})
            row["card_count"] += 1
            row["max_action_score"] = max(row["max_action_score"], int(c.get("action_score") or 0))
            row["total_amount"] += int(c.get("amount") or 0)
            if len(row["linked_cards"]) < 10:
                row["linked_cards"].append(c.get("card_id"))
    out = []
    for row in gaps.values():
        row["linked_cards"] = ", ".join([x for x in row["linked_cards"] if x])
        row["priority"] = int(row["max_action_score"] * 0.6 + min(40, row["card_count"] * 6))
        out.append(row)
    return sorted(out, key=lambda r: (-r["priority"], -r["total_amount"]))[:100]


def _parse_iso_date(value: Any) -> Optional[_dt.date]:
    try:
        if not value:
            return None
        return _dt.date.fromisoformat(str(value))
    except Exception:
        return None


def build_optimized_extraction_plan(extraction_cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_account: Dict[str, List[Dict[str, Any]]] = {}
    for e in extraction_cards:
        key = str(e.get("account_ref") or e.get("target") or "対象未整理")
        by_account.setdefault(key, []).append(e)
    plans = []
    for account_ref, rows in by_account.items():
        intervals = []
        for e in rows:
            start = _parse_iso_date(e.get("range_from"))
            end = _parse_iso_date(e.get("range_to"))
            if not start or not end:
                continue
            intervals.append([start, end, [e]])
        intervals.sort(key=lambda x: x[0])
        merged: List[List[Any]] = []
        for start, end, es in intervals:
            if not merged or start > merged[-1][1] + _dt.timedelta(days=7):
                merged.append([start, end, list(es)])
            else:
                merged[-1][1] = max(merged[-1][1], end)
                merged[-1][2].extend(es)
        for start, end, es in merged:
            cards = sorted({x.get("linked_card") for x in es if x.get("linked_card")})
            purpose = " / ".join([x.get("purpose", "") for x in es[:3] if x.get("purpose")])
            first = es[0] if es else {}
            plans.append({
                "plan_id": f"EP-{len(plans)+1:04d}",
                "target": first.get("target") or account_ref,
                "person": first.get("person") or "",
                "bank": first.get("bank") or "",
                "branch": first.get("branch") or "",
                "account_type": first.get("account_type") or "",
                "account_number": first.get("account_number") or "",
                "account_ref": account_ref,
                "range_from": start.isoformat(),
                "range_to": end.isoformat(),
                "days": (end - start).days + 1,
                "linked_cards": ", ".join(cards),
                "card_count": len(cards),
                "priority": max([int(x.get("priority") or 0) for x in es] or [0]),
                "pick_fields": "日付、時刻、出金、入金、摘要、取扱店、機番、残高、相手方表示、伝票番号があれば伝票番号",
                "purpose": purpose,
                "note": "重複する追加抽出範囲を統合した作業計画です。",
            })
    return sorted(plans, key=lambda r: (-int(r.get("priority") or 0), r.get("range_from") or ""))[:100]

def build_action_board(cards: List[Dict[str, Any]], extraction_plan: List[Dict[str, Any]], evidence_gaps: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for p in extraction_plan[:40]:
        rows.append({"stage": "追加抽出", "priority": p.get("priority"), "target": p.get("target"), "task": f"{p.get('range_from')}〜{p.get('range_to')} を追加抽出", "reason": p.get("purpose"), "linked": p.get("linked_cards")})
    for g in evidence_gaps[:30]:
        rows.append({"stage": "資料確認", "priority": g.get("priority"), "target": "複数", "task": g.get("gap"), "reason": f"関連カード{g.get('card_count')}件、最高優先度{g.get('max_action_score')}", "linked": g.get("linked_cards")})
    for c in cards[:30]:
        rows.append({"stage": "質問", "priority": c.get("action_score"), "target": c.get("target"), "task": c.get("question"), "reason": c.get("title"), "linked": c.get("card_id")})
    return sorted(rows, key=lambda r: -int(r.get("priority") or 0))[:120]


OPEN_REVIEW_STATUSES = {"未確認", "保留", "採用", "確認対象"}
CLOSED_REVIEW_STATUSES = {"除外", "確認済"}


def is_open_review(card: Dict[str, Any]) -> bool:
    return str(card.get("review_status") or "未確認") not in CLOSED_REVIEW_STATUSES


def linked_card_ids(value: Any) -> List[str]:
    if not value:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    return [x.strip() for x in re.split(r"[,、/\s]+", str(value)) if x.strip().startswith("PC-")]




def priority_label(score: Any) -> str:
    try:
        n = int(score or 0)
    except Exception:
        n = 0
    if n >= 80:
        return "最優先"
    if n >= 60:
        return "早めに確認"
    if n >= 40:
        return "確認対象"
    return "後で確認"



def build_primary_cards(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """初期表示用。詳細候補を除き、作業につながるカードだけを上位表示する。

    同じ取引を材料にした下位カテゴリ（例: 資金移動カードと同じ出金の現金化カード、
    同じ取引の節目額カード）は詳細側に残し、初期表示では代表カードだけを出す。
    """
    grouped: Dict[Tuple[str, str, str, int], Dict[str, Any]] = {}
    for c in cards:
        cat = str(c.get("category") or "")
        status = str(c.get("review_status") or "未確認")
        action = int(c.get("action_score") or 0)
        risk = int(c.get("risk_score") or 0)
        if status in CLOSED_REVIEW_STATUSES:
            continue
        if cat == "節目額" and action < 70 and risk < 80:
            continue
        if action < 45 and risk < 60:
            continue
        key = (cat, str(c.get("target") or c.get("person") or ""), str(c.get("title") or ""), int(c.get("amount") or 0))
        existing = grouped.get(key)
        if existing:
            existing["similar_count"] = int(existing.get("similar_count") or 1) + 1
            linked = existing.setdefault("similar_card_ids", [])
            if c.get("card_id"):
                linked.append(c.get("card_id"))
            if int(c.get("action_score") or 0) > int(existing.get("action_score") or 0):
                count = existing.get("similar_count")
                ids = existing.get("similar_card_ids")
                grouped[key] = c
                grouped[key]["similar_count"] = count
                grouped[key]["similar_card_ids"] = ids
        else:
            c["similar_count"] = 1
            c["similar_card_ids"] = [c.get("card_id")] if c.get("card_id") else []
            grouped[key] = c

    category_order = {"資金移動": 0, "現金化": 1, "入金原資": 2, "小口集約": 3, "節目額": 4}
    ordered = sorted(grouped.values(), key=lambda c: (
        category_order.get(str(c.get("category") or ""), 9),
        -int(c.get("priority_score") or 0),
        -int(c.get("action_score") or 0),
        -int(c.get("risk_score") or 0),
        -int(c.get("amount") or 0),
    ))

    # すでに整理済みの代表カードがある取引は、同じ取引を材料にする
    # 下位カードを初期表示に再浮上させない。
    # 例: 資金移動カードを確認済みにした後、同じ出金の現金化カードや
    # 同じ入金の節目額カードが先頭に出て作業が増えたように見える状態を防ぐ。
    closed_cover_keys: set = set()
    closed_cover_tx_ids: set = set()
    for c in cards:
        cat = str(c.get("category") or "")
        if cat not in {"資金移動", "現金化", "入金原資", "小口集約"}:
            continue
        status = str(c.get("review_status") or "未確認")
        done = str(c.get("done_status") or "未完了")
        if status == "確認済" or done == "完了":
            closed_cover_keys.update(set(c.get("tx_stable_keys") or []))
            closed_cover_tx_ids.update(set(c.get("tx_ids") or []))

    # 初期表示の重複抑制。同じ取引を含むカードが既に上位カテゴリで出ている場合、
    # 下位カテゴリのカードは詳細側に回す。これにより、同じ100万円取引が
    # 「資金移動」「現金化」「節目額」と3枚並ぶ状態を避ける。
    selected: List[Dict[str, Any]] = []
    used_keys: set = set()
    used_tx_ids: set = set()
    for c in ordered:
        stable_keys = set(c.get("tx_stable_keys") or [])
        tx_ids = set(c.get("tx_ids") or [])
        cat = str(c.get("category") or "")
        if cat in {"現金化", "入金原資", "節目額", "小口集約"}:
            if (stable_keys and stable_keys & closed_cover_keys) or (tx_ids and tx_ids & closed_cover_tx_ids):
                c["primary_suppressed_reason"] = "同じ取引を含む代表カードが整理済みのため、詳細側に表示。"
                continue
        overlaps = bool((stable_keys and stable_keys & used_keys) or (tx_ids and tx_ids & used_tx_ids))
        if overlaps and cat in {"現金化", "入金原資", "節目額", "小口集約"}:
            c["primary_suppressed_reason"] = "同じ取引を含む上位確認カードがあるため、詳細側に表示。"
            continue
        selected.append(c)
        used_keys.update(stable_keys)
        used_tx_ids.update(tx_ids)
        if len(selected) >= 12:
            break
    return selected

def enrich_card_plain_fields(cards: List[Dict[str, Any]]) -> None:
    """画面表示用の短文を付与する。分析の結論ではなく、次の作業に落とすための説明。"""
    for c in cards:
        amount = money(c.get("amount"))
        cat = str(c.get("category") or "確認")
        title = str(c.get("title") or "確認候補")
        target = str(c.get("target") or c.get("person") or "対象未整理")
        facts = [str(x) for x in (c.get("supporting_facts") or []) if str(x).strip()]
        missing = [str(x) for x in (c.get("missing_facts") or []) if str(x).strip()]
        c["display_priority"] = priority_label(c.get("action_score"))
        c["short_reason"] = " / ".join(facts[:3]) if facts else f"{cat}として確認対象になった取引です。"
        c["short_gap"] = " / ".join(missing[:3]) if missing else "前後明細・関係資料で確認。"
        c["plain_title"] = f"{target}｜{title}｜{amount}"
        c["plain_next"] = c.get("next_action") or "前後明細と関係資料を確認。"
        c["ignore_hint"] = "生活費・返済・本人管理・正当な換価収入として資料と説明が整う場合は、優先度を下げられます。"


def build_input_guidance(txs: List[Transaction], issues: List[Dict[str, Any]], family: Dict[str, Any], same_account_offsets: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """初回入力時のつまずきを作業カード化する。"""
    out: List[Dict[str, Any]] = []
    for o in (same_account_offsets or [])[:30]:
        out.append({
            "guide_id": f"IG-{len(out)+1:03d}",
            "level": "warning",
            "where": f"{o.get('date','')} {o.get('bank','')}{o.get('branch','')} {o.get('name','')} {o.get('account_number','')}",
            "what": "同一口座内の同日近似額出入金",
            "fix": o.get("message") or "原票で取消・訂正・入力列・別取引混入を確認してください。",
            "linked": ",".join(o.get("tx_ids") or []),
        })
    severe = [i for i in issues if str(i.get("severity")) in ("error", "warning")]
    for i in severe[:30]:
        out.append({
            "guide_id": f"IG-{len(out)+1:04d}",
            "level": i.get("severity"),
            "where": i.get("location"),
            "what": i.get("message"),
            "fix": "原票の該当行を見直し、日付・金額・入出金列・名義を確認してください。",
            "priority": 95 if i.get("severity") == "error" else 80,
        })
    # 行の中で入出金が両方あるものは、取消/訂正/列ズレ確認として別途出す
    for t in txs:
        if t.amount_in and t.amount_out:
            out.append({
                "guide_id": f"IG-{len(out)+1:04d}",
                "level": "warning",
                "where": f"取引{t.row_number}",
                "what": "同じ行に出金と入金が両方入っています。",
                "fix": "原票で入出金列の読み取り、取消・訂正取引、同一日の別取引混入を確認してください。",
                "priority": 88,
            })
    # 重複入力の可能性
    seen = {}
    for t in txs:
        seen.setdefault(t.stable_key, []).append(t)
    for rows in seen.values():
        if len(rows) >= 2:
            r0 = rows[0]
            out.append({
                "guide_id": f"IG-{len(out)+1:04d}",
                "level": "info",
                "where": f"{r0.date or ''} {r0.name} {money(r0.amount_out or r0.amount_in)}",
                "what": f"同一内容と思われる取引が{len(rows)}件あります。",
                "fix": "重複入力か、同一条件の別取引かを原票で確認してください。",
                "priority": 60,
            })
    fam_names = set(compact_name((p.get("name") or "")) for p in (family.get("people") or []) if p.get("name"))
    tx_names = set(compact_name(t.name) for t in txs if t.name)
    unknown_names = sorted([n for n in tx_names if n and n not in fam_names])
    for n in unknown_names[:20]:
        out.append({
            "guide_id": f"IG-{len(out)+1:04d}",
            "level": "info",
            "where": n,
            "what": "家族情報に登録されていない名義の取引があります。",
            "fix": "関係者か表記ゆれかを確認し、必要なら家族・関係者情報へ追加してください。",
            "priority": 55,
        })
    if not family.get("deceased"):
        out.append({
            "guide_id": f"IG-{len(out)+1:04d}",
            "level": "warning",
            "where": "家族情報",
            "what": "被相続人が特定できていません。",
            "fix": "家族情報の続柄欄に『被相続人』を入れてください。被相続人関与・死亡日前後の優先度判定に必要です。",
            "priority": 98,
        })
    if not family.get("inheritance_date"):
        out.append({
            "guide_id": f"IG-{len(out)+1:04d}",
            "level": "warning",
            "where": "家族情報",
            "what": "相続開始日が未設定です。",
            "fix": "相続開始日を入力してください。死亡日前後の集中確認・直前出金の優先度判定に必要です。",
            "priority": 96,
        })
    return sorted(out, key=lambda r: -int(r.get("priority") or 0))[:80]


def build_work_queue(cards: List[Dict[str, Any]], extraction_plan: List[Dict[str, Any]], evidence_gaps: List[Dict[str, Any]], questionnaires: List[Dict[str, Any]], input_guidance: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
    """判断状態を加味した未処理キュー。

    画面で最初に見る作業キューは、細かい不足資料を何行も並べない。
    1カードにつき、カード確認・追加抽出・資料確認・質問の必要作業を束ねて出す。
    """
    card_by_id = {str(c.get("card_id")): c for c in cards}
    open_cards = [c for c in cards if is_open_review(c)]
    open_ids = {str(c.get("card_id")) for c in open_cards}
    rows: List[Dict[str, Any]] = []

    for g in (input_guidance or [])[:30]:
        rows.append({"queue_id": f"WQ-{len(rows)+1:04d}", "stage": "入力確認", "priority": int(g.get("priority") or 0), "status": "未処理", "target": g.get("where"), "category": "入力確認", "task": g.get("what"), "reason": g.get("fix"), "linked": g.get("guide_id"), "done_definition": "入力内容を見直し、必要なら該当行を修正する。"})

    for c in open_cards[:80]:
        status = str(c.get("review_status") or "未確認")
        pri = int(c.get("action_score") or 0)
        if status == "保留":
            pri += 8
        elif status in {"採用", "確認対象"}:
            pri += 4
        rows.append({"queue_id": f"WQ-{len(rows)+1:04d}", "stage": "カード確認", "priority": min(100, pri), "status": status, "target": c.get("target"), "category": c.get("category"), "task": c.get("plain_next") or c.get("next_action") or c.get("question") or c.get("title"), "reason": f"{c.get('title')}｜確認順:{c.get('display_priority') or priority_label(c.get('action_score'))}", "linked": c.get("card_id"), "done_definition": "判断状態と判断メモを残す。"})

    # 追加抽出は、統合計画を使いつつ、初期表示カードに紐づく未処理分だけ出す。
    seen_extract: set = set()
    for p in extraction_plan:
        ids = linked_card_ids(p.get("linked_cards"))
        active = [card_by_id.get(i) for i in ids if i in card_by_id and i in open_ids]
        active = [c for c in active if (c.get("extraction_status") or "未処理") == "未処理"]
        if ids and not active:
            continue
        active_linked = ", ".join(str(c.get("card_id")) for c in active if c and c.get("card_id")) or p.get("linked_cards")
        dedupe_key = (p.get("target"), p.get("range_from"), p.get("range_to"), active_linked)
        if dedupe_key in seen_extract:
            continue
        seen_extract.add(dedupe_key)
        rows.append({"queue_id": f"WQ-{len(rows)+1:04d}", "stage": "追加抽出", "priority": min(100, int(p.get("priority") or 0) + 6), "status": "未処理", "target": p.get("target"), "category": "原票追加抽出", "task": f"{p.get('range_from')}〜{p.get('range_to')} を追加抽出", "reason": p.get("purpose"), "linked": active_linked, "done_definition": "指定期間の明細を追加入力し、関連カードの『追加抽出』を更新する。"})

    # 資料確認は evidence_gaps をそのまま並べると同一カードで多数行になるため、カード単位に束ねる。
    for c in open_cards[:80]:
        if (c.get("document_status") or "未処理") != "未処理":
            continue
        docs = [str(x) for x in (c.get("documents") or []) if str(x).strip()]
        missing = [str(x) for x in (c.get("missing_facts") or []) if str(x).strip()]
        task_items = docs[:4] or missing[:4]
        if not task_items:
            continue
        more = " ほか" if len(docs) + len(missing) > len(task_items) else ""
        rows.append({"queue_id": f"WQ-{len(rows)+1:04d}", "stage": "資料確認", "priority": max(40, int(c.get("action_score") or 0) - 8), "status": "未処理", "target": c.get("target"), "category": "資料確認", "task": " / ".join(task_items) + more, "reason": c.get("short_gap") or "必要資料と不足材料を確認。", "linked": c.get("card_id"), "done_definition": "資料の有無・提示不可理由・代替資料を判断メモに残し、関連カードの『資料』を更新する。"})

    # 質問も初期表示カードから作る。詳細候補だけの質問が混ざると、作業の焦点がぶれるため。
    by_person: Dict[str, List[Dict[str, Any]]] = {}
    for c in open_cards:
        if (c.get("question_status") or "未処理") != "未処理":
            continue
        person = str(c.get("person") or c.get("target") or "関係者")
        by_person.setdefault(person, []).append(c)
    for person, related in by_person.items():
        questions = []
        for c in related:
            q = str(c.get("question") or "").strip()
            if q and q not in questions:
                questions.append(q)
        if not questions:
            continue
        rows.append({"queue_id": f"WQ-{len(rows)+1:04d}", "stage": "質問", "priority": max(int(c.get("action_score") or 0) for c in related), "status": "未処理", "target": person, "category": "人物別質問", "task": " / ".join(questions[:3]), "reason": f"未処理カード{len(related)}件に関連。", "linked": ", ".join(c.get("card_id", "") for c in related[:8]), "done_definition": "回答内容、提出資料、追加確認の要否を判断メモへ反映し、関連カードの『質問』を更新する。"})

    rows = sorted(rows, key=lambda r: (-int(r.get("priority") or 0), str(r.get("stage")), str(r.get("target"))))
    for i, r in enumerate(rows[:180], 1):
        r["queue_id"] = f"WQ-{i:04d}"
    return rows[:180]

def count_by(rows: List[Dict[str, Any]], key: str) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for r in rows:
        v = str(r.get(key) or "")
        out[v] = out.get(v, 0) + 1
    return out


def build_operation_navigator(input_guidance: List[Dict[str, Any]], primary_cards: List[Dict[str, Any]], all_cards: List[Dict[str, Any]], work_queue: List[Dict[str, Any]]) -> Dict[str, Any]:
    """初期画面で迷わないための作業ナビ。

    詳細分析を消さず、画面先頭では「何から処理するか」だけに絞る。
    入力確認が強い場合は確認カードより先に入力確認を出す。
    """
    high_input = [g for g in input_guidance if int(g.get("priority") or 0) >= 80]
    open_primary = [c for c in primary_cards if is_open_review(c)]
    open_all = [c for c in all_cards if is_open_review(c)]
    detail_count = max(0, len(open_all) - len(open_primary))

    if high_input:
        status = "入力確認を先に処理"
        message = "入力内容に確認点があります。分析結果を見る前に、原票と入力行を確認してください。"
        focus = "入力確認"
    elif open_primary:
        status = "確認カードを処理"
        message = "上位の確認カードから順に、追加で拾う明細・資料・質問を処理してください。"
        focus = "確認カード"
    elif work_queue:
        status = "残作業を処理"
        message = "大きな確認カードは整理済みです。残っている作業キューを処理してください。"
        focus = work_queue[0].get("stage") or "作業"
    else:
        status = "未処理作業なし"
        message = "現入力範囲では、先頭に出す作業はありません。必要に応じて詳細表と原票を確認してください。"
        focus = "なし"

    steps: List[Dict[str, Any]] = []
    for g in high_input[:3]:
        steps.append({
            "order": len(steps) + 1,
            "stage": "入力確認",
            "target": g.get("where") or "入力行",
            "task": g.get("what") or "入力確認",
            "reason": g.get("fix") or "原票と入力内容を確認してください。",
            "done_definition": "該当行を確認し、必要なら入力を修正する。",
        })
    if len(steps) < 3:
        for w in work_queue:
            if len(steps) >= 3:
                break
            # 入力確認がすでに入っている場合、同じ入力確認だけで埋まりすぎないようにする
            if high_input and w.get("stage") == "入力確認" and len([x for x in steps if x.get("stage") == "入力確認"]) >= 2:
                continue
            steps.append({
                "order": len(steps) + 1,
                "stage": w.get("stage"),
                "target": w.get("target"),
                "task": w.get("task"),
                "reason": w.get("reason"),
                "done_definition": w.get("done_definition"),
            })
    if not steps:
        steps.append({
            "order": 1,
            "stage": "確認",
            "target": "全体",
            "task": "詳細表と原票を必要に応じて確認",
            "reason": "先頭に出す未処理作業はありません。",
            "done_definition": "必要な確認がなければ分析結果を保存する。",
        })

    return {
        "status": status,
        "message": message,
        "focus": focus,
        "input_attention_count": len(input_guidance),
        "high_input_attention_count": len(high_input),
        "primary_card_count": len(primary_cards),
        "open_primary_count": len(open_primary),
        "detail_open_count": detail_count,
        "work_queue_count": len(work_queue),
        "steps": steps,
        "note": "詳細候補は折りたたみ内に残しています。先頭画面では、処理順を優先して表示しています。",
    }

def build_completion_dashboard(cards: List[Dict[str, Any]], work_queue: List[Dict[str, Any]], evidence_gaps: List[Dict[str, Any]], extraction_plan: List[Dict[str, Any]]) -> Dict[str, Any]:
    counts = {"未確認": 0, "確認対象": 0, "採用": 0, "除外": 0, "保留": 0, "確認済": 0}
    for c in cards:
        s = str(c.get("review_status") or "未確認")
        counts[s] = counts.get(s, 0) + 1
    open_cards = [c for c in cards if is_open_review(c)]
    high_open = [c for c in open_cards if int(c.get("action_score") or 0) >= 75]
    blockers = []
    if high_open:
        blockers.append(f"優先度75以上の未完了カードが{len(high_open)}件あります。")
    if any(str(c.get("review_status") or "") == "保留" for c in cards):
        blockers.append("保留カードがあります。保留理由と次の確認を明確にしてください。")
    if evidence_gaps and open_cards:
        blockers.append("未完了カードに紐づく資料不足があります。")
    if extraction_plan and open_cards:
        blockers.append("未完了カードに紐づく追加抽出範囲があります。")
    step_counts = {
        "追加抽出": count_by(cards, "extraction_status"),
        "資料": count_by(cards, "document_status"),
        "質問": count_by(cards, "question_status"),
        "完了": count_by(cards, "done_status"),
    }
    done_count = step_counts["完了"].get("完了", 0)
    return {"card_total": len(cards), "open_count": len(open_cards), "closed_count": len(cards) - len(open_cards), "done_count": done_count, "high_open_count": len(high_open), "open_amount_total": sum(int(c.get("amount") or 0) for c in open_cards), "max_open_action_score": max([int(c.get("action_score") or 0) for c in open_cards] or [0]), "work_queue_count": len(work_queue), "next_stage": work_queue[0].get("stage") if work_queue else "なし", "next_task": work_queue[0].get("task") if work_queue else "未処理作業なし", "status_counts": counts, "step_counts": step_counts, "closure_ready": len(blockers) == 0, "blockers": blockers, "note": "これは調査作業の進捗表示であり、課税判断の結論ではありません。"}


def build_review_warnings(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for c in cards:
        s = str(c.get("review_status") or "未確認")
        memo = str(c.get("review_memo") or "").strip()
        risk = int(c.get("risk_score") or 0)
        evi = int(c.get("evidence_score") or 0)
        action = int(c.get("action_score") or 0)
        if s in {"採用", "確認対象", "除外", "確認済"} and not memo:
            rows.append({"level": "warning", "card_id": c.get("card_id"), "status": s, "target": c.get("target"), "message": "判断済みですが判断メモが空欄です。後で根拠が追えません。"})
        doc_status = c.get("document_status") or "未処理"
        if s in {"採用", "確認対象"} and doc_status not in {"資料確認済", "不要"} and int(c.get("document_evidence_score") or 0) < 20:
            rows.append({"level": "warning", "card_id": c.get("card_id"), "status": s, "target": c.get("target"), "message": "確認対象にしていますが、外部資料の確認状況が未整理です。確認済み・不要・一部確認のいずれかを状態欄に残してください。"})
        if s == "除外" and (risk >= 75 or action >= 75) and not memo:
            rows.append({"level": "danger", "card_id": c.get("card_id"), "status": s, "target": c.get("target"), "message": "高優先度カードを除外しています。除外理由メモなしでは危険です。"})
        if s == "保留" and not memo:
            rows.append({"level": "info", "card_id": c.get("card_id"), "status": s, "target": c.get("target"), "message": "保留理由と次に見る資料を書いてください。"})
        if c.get("done_status") == "完了" and s not in {"除外", "確認済"}:
            rows.append({"level": "warning", "card_id": c.get("card_id"), "status": s, "target": c.get("target"), "message": "完了になっていますが、判断が完了系ではありません。判断状態も更新してください。"})
        if c.get("done_status") == "完了" and (c.get("extraction_status") or "未処理") == "未処理" and (c.get("document_status") or "未処理") == "未処理" and not memo:
            rows.append({"level": "warning", "card_id": c.get("card_id"), "status": s, "target": c.get("target"), "message": "完了になっていますが、追加抽出・資料確認・判断メモがいずれも未整理です。"})
    return rows[:120]


def build_handover_memo(case_id: str, result: Dict[str, Any], dashboard: Dict[str, Any], work_queue: List[Dict[str, Any]], warnings: List[Dict[str, Any]]) -> str:
    lines = ["【相続インサイト Python補助 引継ぎメモ】", f"案件ID: {case_id}", f"作成日時: {_dt.datetime.now().isoformat(timespec='seconds')}", "", "■ 進捗"]
    lines.append(f"カード総数: {dashboard.get('card_total')} / 未完了: {dashboard.get('open_count')} / 高優先未完了: {dashboard.get('high_open_count')}")
    lines.append(f"次の作業: {dashboard.get('next_stage')} - {dashboard.get('next_task')}")
    if dashboard.get("blockers"):
        lines.append("■ 完了前の阻害要因")
        for b in dashboard.get("blockers") or []:
            lines.append("・" + str(b))
    lines += ["", "■ 次にやること"]
    for r in work_queue[:12]:
        lines.append(f"・[{r.get('stage')}] {r.get('target')}｜優先{r.get('priority')}｜{r.get('task')}｜完了条件:{r.get('done_definition')}")
    if warnings:
        lines += ["", "■ 判断メモ・状態の注意"]
        for w in warnings[:12]:
            lines.append(f"・{w.get('card_id')} {w.get('target')}｜{w.get('message')}")
    lines += ["", "※ 抽出入力前提のため、未検出は不存在ではなく『現入力範囲では確認できない』という扱い。"]
    return "\n".join(lines)


def build_scenario_pathways(cards: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    scenario_map = {
        "資金移動": "贈与・貸付・預け金・名義財産",
        "現金化": "現金保管・費消・家族交付",
        "入金原資": "入金原資・資産換価・保険金・借入",
        "小口集約": "小口分散・連続贈与・生活費",
        "節目額": "節目額直下・贈与税/分散確認",
    }
    by = {}
    for c in cards:
        s = scenario_map.get(str(c.get("category")), str(c.get("category") or "その他"))
        by.setdefault(s, []).append(c)
    out = []
    for scenario, rows in by.items():
        rows = sorted(rows, key=lambda c: -int(c.get("action_score") or 0))
        avg_evi = int(sum(int(c.get("evidence_score") or 0) for c in rows) / max(1, len(rows)))
        if avg_evi >= 70:
            status = "骨子化可能。ただし反証確認は必要。"
        elif avg_evi >= 45:
            status = "追加資料があれば説明骨子化可能。"
        else:
            status = "現時点では材料不足。まず追加抽出と資料確認。"
        out.append({
            "scenario": scenario,
            "card_count": len(rows),
            "total_amount": sum(int(c.get("amount") or 0) for c in rows),
            "max_action_score": max(int(c.get("action_score") or 0) for c in rows),
            "evidence_readiness": avg_evi,
            "status": status,
            "support": " / ".join(["; ".join(c.get("supporting_facts") or []) for c in rows[:3] if c.get("supporting_facts")]),
            "missing": " / ".join(sorted({m for c in rows for m in (c.get("missing_facts") or [])})[:8]),
            "next_step": rows[0].get("next_action", "") if rows else "",
            "linked_cards": ", ".join([c.get("card_id", "") for c in rows[:10]]),
        })
    return sorted(out, key=lambda r: (-r["max_action_score"], -r["total_amount"]))[:50]


def build_case_diff(current: Dict[str, Any], previous: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not previous:
        return {"has_previous": False, "message": "同一案件IDの保存済み分析がありません。今回分析を保存すると、次回から差分比較できます。", "new_cards": [], "removed_cards": [], "changed_cards": []}
    cur_cards = current.get("priority_cards") or []
    prev_cards = previous.get("priority_cards") or []
    cur_by = {card_signature(c): c for c in cur_cards}
    prev_by = {card_signature(c): c for c in prev_cards}
    new = [cur_by[k] for k in cur_by.keys() - prev_by.keys()]
    removed = [prev_by[k] for k in prev_by.keys() - cur_by.keys()]
    changed = []
    for k in cur_by.keys() & prev_by.keys():
        c, p = cur_by[k], prev_by[k]
        if int(c.get("action_score") or 0) != int(p.get("action_score") or 0) or int(c.get("evidence_score") or 0) != int(p.get("evidence_score") or 0):
            changed.append({"card_id": c.get("card_id"), "target": c.get("target"), "category": c.get("category"), "action_before": p.get("action_score"), "action_after": c.get("action_score"), "evidence_before": p.get("evidence_score"), "evidence_after": c.get("evidence_score")})
    return {
        "has_previous": True,
        "previous_createdAt": previous.get("createdAt"),
        "new_count": len(new),
        "removed_count": len(removed),
        "changed_count": len(changed),
        "new_cards": [{"card_id": c.get("card_id"), "category": c.get("category"), "target": c.get("target"), "amount": c.get("amount"), "action_score": c.get("action_score"), "title": c.get("title")} for c in new[:50]],
        "removed_cards": [{"category": c.get("category"), "target": c.get("target"), "amount": c.get("amount"), "title": c.get("title")} for c in removed[:50]],
        "changed_cards": changed[:50],
        "message": f"新規{len(new)}件、消滅{len(removed)}件、スコア変動{len(changed)}件。消滅は不存在ではなく、入力範囲や抽出行の変更の可能性があります。",
    }


def normalize_case_id(raw_id: Any) -> str:
    raw = norm_text(raw_id)
    if not raw:
        return ""
    normalized = re.sub(r"[^0-9A-Za-zぁ-んァ-ン一-龥_\-]+", "_", raw).strip("_")[:80]
    return normalized or "CASE"


def get_case_id(payload: Dict[str, Any]) -> str:
    settings = payload.get("settings") or {}
    raw_id = settings.get("caseId") or payload.get("caseId") or ""
    cid = normalize_case_id(raw_id)
    if cid:
        return cid
    raw = payload.get("raw") or {}
    seed = json.dumps(raw, ensure_ascii=False, sort_keys=True, default=str)[:100000]
    return "CASE-" + hashlib.sha1(seed.encode("utf-8", "ignore")).hexdigest()[:10]


def case_db_path() -> Path:
    env_path = os.environ.get("IH_CASE_DB_PATH")
    if env_path:
        return Path(env_path)
    try:
        base = Path(__file__).resolve().parent
    except Exception:
        base = Path.cwd()
    return base / CASE_DB_NAME


def ensure_case_db() -> sqlite3.Connection:
    con = sqlite3.connect(str(case_db_path()))
    con.execute("""CREATE TABLE IF NOT EXISTS analysis_runs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        result_hash TEXT NOT NULL,
        summary_json TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        result_json TEXT NOT NULL
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_analysis_runs_case ON analysis_runs(case_id, id DESC)")
    con.execute("""CREATE TABLE IF NOT EXISTS card_reviews(
        case_id TEXT NOT NULL,
        card_key TEXT NOT NULL,
        card_id TEXT,
        category TEXT,
        target TEXT,
        title TEXT,
        amount INTEGER,
        status TEXT NOT NULL,
        memo TEXT,
        extraction_status TEXT DEFAULT '未処理',
        document_status TEXT DEFAULT '未処理',
        question_status TEXT DEFAULT '未処理',
        done_status TEXT DEFAULT '未完了',
        updated_at TEXT NOT NULL,
        PRIMARY KEY(case_id, card_key)
    )""")
    # 既存DBを壊さず段階移行する。
    cols = {row[1] for row in con.execute("PRAGMA table_info(card_reviews)").fetchall()}
    for col, ddl in {
        "extraction_status": "ALTER TABLE card_reviews ADD COLUMN extraction_status TEXT DEFAULT '未処理'",
        "document_status": "ALTER TABLE card_reviews ADD COLUMN document_status TEXT DEFAULT '未処理'",
        "question_status": "ALTER TABLE card_reviews ADD COLUMN question_status TEXT DEFAULT '未処理'",
        "done_status": "ALTER TABLE card_reviews ADD COLUMN done_status TEXT DEFAULT '未完了'",
    }.items():
        if col not in cols:
            con.execute(ddl)
    con.execute("CREATE INDEX IF NOT EXISTS idx_card_reviews_case ON card_reviews(case_id, updated_at DESC)")
    con.execute("""CREATE TABLE IF NOT EXISTS case_events(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        case_id TEXT NOT NULL,
        created_at TEXT NOT NULL,
        event_type TEXT NOT NULL,
        detail_json TEXT NOT NULL
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_case_events_case ON case_events(case_id, id DESC)")
    con.commit()
    return con


def log_case_event(con: sqlite3.Connection, case_id: str, event_type: str, detail: Dict[str, Any]) -> None:
    con.execute(
        "INSERT INTO case_events(case_id, created_at, event_type, detail_json) VALUES(?,?,?,?)",
        (case_id, _dt.datetime.now().isoformat(timespec="seconds"), event_type, json.dumps(detail or {}, ensure_ascii=False)),
    )


def latest_case_result(case_id: str) -> Optional[Dict[str, Any]]:
    con = ensure_case_db()
    try:
        row = con.execute("SELECT result_json FROM analysis_runs WHERE case_id=? ORDER BY id DESC LIMIT 1", (case_id,)).fetchone()
        if not row:
            return None
        return json.loads(row[0])
    finally:
        con.close()


def save_case_run(case_id: str, payload: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    con = ensure_case_db()
    try:
        result_hash = stable_json_hash({"summary": result.get("summary"), "priority_cards": result.get("priority_cards"), "extraction_plan": result.get("extraction_plan")})
        con.execute(
            "INSERT INTO analysis_runs(case_id, created_at, result_hash, summary_json, payload_json, result_json) VALUES(?,?,?,?,?,?)",
            (case_id, _dt.datetime.now().isoformat(timespec="seconds"), result_hash, json.dumps(result.get("summary") or {}, ensure_ascii=False), json.dumps(payload, ensure_ascii=False), json.dumps(result, ensure_ascii=False)),
        )
        log_case_event(con, case_id, "analysis_saved", {"result_hash": result_hash, "priority_card_count": len(result.get("priority_cards") or []), "open_count": (result.get("review_summary") or {}).get("open_count")})
        con.commit()
        count = con.execute("SELECT COUNT(*) FROM analysis_runs WHERE case_id=?", (case_id,)).fetchone()[0]
        return {"ok": True, "case_id": case_id, "run_count": count, "db_path": str(case_db_path()), "result_hash": result_hash}
    finally:
        con.close()


def list_case_runs(limit: int = 50) -> List[Dict[str, Any]]:
    con = ensure_case_db()
    try:
        rows = con.execute("""
            SELECT case_id, MAX(id) AS last_id, MAX(created_at) AS last_created, COUNT(*) AS run_count
            FROM analysis_runs GROUP BY case_id ORDER BY last_id DESC LIMIT ?
        """, (limit,)).fetchall()
        return [{"case_id": r[0], "last_id": r[1], "last_created": r[2], "run_count": r[3]} for r in rows]
    finally:
        con.close()



def _clean_choice(value: Any, allowed: set, default: str) -> str:
    v = norm_text(value or default)
    return v if v in allowed else default


def save_case_reviews(case_id: str, reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
    allowed_status = {"未確認", "確認対象", "採用", "除外", "保留", "確認済"}
    allowed_extraction = {"未処理", "追加抽出済", "不要"}
    allowed_document = {"未処理", "一部確認", "資料確認済", "不要"}
    allowed_question = {"未処理", "質問済", "不要"}
    allowed_done = {"未完了", "完了"}
    now = _dt.datetime.now().isoformat(timespec="seconds")
    con = ensure_case_db()
    saved = 0
    try:
        for r in reviews or []:
            card_key = norm_text(r.get("card_key") or "")
            if not card_key:
                continue
            status = _clean_choice(r.get("status"), allowed_status, "未確認")
            memo = norm_text(r.get("memo") or "")[:2000]
            extraction_status = _clean_choice(r.get("extraction_status"), allowed_extraction, "未処理")
            document_status = _clean_choice(r.get("document_status"), allowed_document, "未処理")
            question_status = _clean_choice(r.get("question_status"), allowed_question, "未処理")
            done_status = _clean_choice(r.get("done_status"), allowed_done, "未完了")
            if done_status == "完了":
                problems = []
                if status in {"未確認", "確認対象", "採用", "保留"}:
                    problems.append("完了にするには判断状態を除外または確認済にしてください")
                if not memo:
                    problems.append("完了にするには判断メモを入力してください")
                if extraction_status == "未処理" and document_status == "未処理" and question_status == "未処理":
                    problems.append("完了にするには追加抽出・資料・質問のいずれかを整理してください")
                if problems:
                    raise ValueError("; ".join(problems))
            if status in {"採用", "除外", "確認済"} and not memo:
                raise ValueError("採用・除外・確認済にする場合は判断メモを入力してください")
            if document_status == "資料確認済" and not memo:
                raise ValueError("資料確認済にする場合は、確認した資料または確認内容を判断メモに入力してください")
            con.execute("""
                INSERT INTO card_reviews(case_id, card_key, card_id, category, target, title, amount, status, memo,
                    extraction_status, document_status, question_status, done_status, updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(case_id, card_key) DO UPDATE SET
                    card_id=excluded.card_id, category=excluded.category, target=excluded.target, title=excluded.title,
                    amount=excluded.amount, status=excluded.status, memo=excluded.memo,
                    extraction_status=excluded.extraction_status, document_status=excluded.document_status,
                    question_status=excluded.question_status, done_status=excluded.done_status,
                    updated_at=excluded.updated_at
            """, (case_id, card_key, norm_text(r.get("card_id") or ""), norm_text(r.get("category") or ""),
                  norm_text(r.get("target") or ""), norm_text(r.get("title") or ""), int(r.get("amount") or 0),
                  status, memo, extraction_status, document_status, question_status, done_status, now))
            saved += 1
        counts = {row[0]: row[1] for row in con.execute("SELECT status, COUNT(*) FROM card_reviews WHERE case_id=? GROUP BY status", (case_id,)).fetchall()}
        step_counts = {
            "extraction": {row[0]: row[1] for row in con.execute("SELECT extraction_status, COUNT(*) FROM card_reviews WHERE case_id=? GROUP BY extraction_status", (case_id,)).fetchall()},
            "document": {row[0]: row[1] for row in con.execute("SELECT document_status, COUNT(*) FROM card_reviews WHERE case_id=? GROUP BY document_status", (case_id,)).fetchall()},
            "question": {row[0]: row[1] for row in con.execute("SELECT question_status, COUNT(*) FROM card_reviews WHERE case_id=? GROUP BY question_status", (case_id,)).fetchall()},
            "done": {row[0]: row[1] for row in con.execute("SELECT done_status, COUNT(*) FROM card_reviews WHERE case_id=? GROUP BY done_status", (case_id,)).fetchall()},
        }
        log_case_event(con, case_id, "reviews_saved", {"saved": saved, "counts": counts, "step_counts": step_counts})
        con.commit()
        return {"ok": True, "case_id": case_id, "saved": saved, "updated_at": now, "counts": counts, "step_counts": step_counts}
    finally:
        con.close()


def list_case_reviews(case_id: str) -> Dict[str, Dict[str, Any]]:
    con = ensure_case_db()
    try:
        rows = con.execute("""
            SELECT card_key, card_id, category, target, title, amount, status, memo,
                   extraction_status, document_status, question_status, done_status, updated_at
            FROM card_reviews WHERE case_id=?
        """, (case_id,)).fetchall()
        return {
            r[0]: {"card_key": r[0], "card_id": r[1], "category": r[2], "target": r[3], "title": r[4], "amount": r[5],
                   "status": r[6], "memo": r[7], "extraction_status": r[8] or "未処理", "document_status": r[9] or "未処理",
                   "question_status": r[10] or "未処理", "done_status": r[11] or "未完了", "updated_at": r[12]}
            for r in rows
        }
    finally:
        con.close()


def apply_case_reviews(case_id: str, cards: List[Dict[str, Any]]) -> Dict[str, Any]:
    reviews = list_case_reviews(case_id)
    counts = {"未確認": 0, "確認対象": 0, "採用": 0, "除外": 0, "保留": 0, "確認済": 0}
    step_counts = {
        "extraction": {"未処理": 0, "追加抽出済": 0, "不要": 0},
        "document": {"未処理": 0, "一部確認": 0, "資料確認済": 0, "不要": 0},
        "question": {"未処理": 0, "質問済": 0, "不要": 0},
        "done": {"未完了": 0, "完了": 0},
    }
    for c in cards:
        key = c.get("card_key") or card_signature(c)
        c["card_key"] = key
        r = reviews.get(key)
        if r:
            c["review_status"] = r.get("status") or "未確認"
            c["review_memo"] = r.get("memo") or ""
            c["extraction_status"] = r.get("extraction_status") or "未処理"
            c["document_status"] = r.get("document_status") or "未処理"
            c["question_status"] = r.get("question_status") or "未処理"
            c["done_status"] = r.get("done_status") or "未完了"
            c["review_updated_at"] = r.get("updated_at") or ""
        else:
            c.setdefault("review_status", "未確認")
            c.setdefault("review_memo", "")
            c.setdefault("extraction_status", "未処理")
            c.setdefault("document_status", "未処理")
            c.setdefault("question_status", "未処理")
            c.setdefault("done_status", "未完了")
        # 判断メモは判断履歴であり、資料確認済みとは別扱い。
        # 資料状態は表示・警告と連動させるが、メモだけでは資料確認扱いにしない。
        doc_status = c.get("document_status") or "未処理"
        if doc_status == "資料確認済":
            c["document_evidence_score"] = max(int(c.get("document_evidence_score") or 0), 70)
            c["document_state_label"] = "資料確認済"
        elif doc_status == "一部確認":
            c["document_evidence_score"] = max(int(c.get("document_evidence_score") or 0), 40)
            c["document_state_label"] = "一部確認"
        elif doc_status == "不要":
            c["document_state_label"] = "資料確認不要"
        else:
            c["document_state_label"] = "資料未確認"
        st = c.get("review_status") or "未確認"
        c["review_memo_present"] = bool(str(c.get("review_memo") or "").strip())
        counts[st] = counts.get(st, 0) + 1
        step_counts["extraction"][c.get("extraction_status") or "未処理"] = step_counts["extraction"].get(c.get("extraction_status") or "未処理", 0) + 1
        step_counts["document"][c.get("document_status") or "未処理"] = step_counts["document"].get(c.get("document_status") or "未処理", 0) + 1
        step_counts["question"][c.get("question_status") or "未処理"] = step_counts["question"].get(c.get("question_status") or "未処理", 0) + 1
        step_counts["done"][c.get("done_status") or "未完了"] = step_counts["done"].get(c.get("done_status") or "未完了", 0) + 1
    open_count = counts.get("未確認", 0) + counts.get("保留", 0) + counts.get("確認対象", 0) + counts.get("採用", 0)
    return {"counts": counts, "step_counts": step_counts, "open_count": open_count, "reviewed_count": len(cards) - counts.get("未確認", 0), "stored_review_count": len(reviews)}

def make_sqlite_result_db(result: Dict[str, Any]) -> bytes:
    fd, path = tempfile.mkstemp(suffix=".sqlite")
    os.close(fd)
    try:
        con = sqlite3.connect(path)
        con.execute("CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT)")
        con.execute("CREATE TABLE json_sections(name TEXT PRIMARY KEY, body TEXT NOT NULL)")
        con.execute("INSERT INTO metadata(key,value) VALUES(?,?)", ("created_at", result.get("createdAt", "")))
        con.execute("INSERT INTO metadata(key,value) VALUES(?,?)", ("schema_version", result.get("schemaVersion", SCHEMA_VERSION)))
        for name in ["summary", "operation_navigator", "input_guidance", "primary_cards", "priority_cards", "card_bundles", "extraction_plan", "action_board", "work_queue", "completion_dashboard", "review_warnings", "evidence_gaps", "scenario_pathways", "case_diff", "review_summary"]:
            con.execute("INSERT INTO json_sections(name, body) VALUES(?,?)", (name, json.dumps(result.get(name), ensure_ascii=False)))
        con.execute("""CREATE TABLE priority_cards(
            card_id TEXT, card_key TEXT, review_status TEXT, review_memo TEXT,
            extraction_status TEXT, document_status TEXT, document_state_label TEXT, question_status TEXT, done_status TEXT,
            category TEXT, target TEXT, amount INTEGER, risk_score INTEGER,
            internal_consistency_score INTEGER, document_evidence_score INTEGER, action_score INTEGER,
            title TEXT, hypothesis TEXT, supporting_facts TEXT, missing_facts TEXT, documents TEXT, question TEXT, next_action TEXT, tx_ids TEXT
        )""")
        for c in result.get("priority_cards") or []:
            con.execute("INSERT INTO priority_cards VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                c.get("card_id"), c.get("card_key"), c.get("review_status"), c.get("review_memo"),
                c.get("extraction_status"), c.get("document_status"), c.get("document_state_label"), c.get("question_status"), c.get("done_status"),
                c.get("category"), c.get("target"), int(c.get("amount") or 0), int(c.get("risk_score") or 0),
                int(c.get("internal_consistency_score") or c.get("evidence_score") or 0), int(c.get("document_evidence_score") or 0), int(c.get("action_score") or 0),
                c.get("title"), c.get("hypothesis"), " / ".join(c.get("supporting_facts") or []), " / ".join(c.get("missing_facts") or []),
                " / ".join(c.get("documents") or []), c.get("question"), c.get("next_action"), ",".join(c.get("tx_ids") or [])
            ))
        con.execute("CREATE TABLE action_board(stage TEXT, priority INTEGER, target TEXT, task TEXT, reason TEXT, linked TEXT)")
        for a in result.get("action_board") or []:
            con.execute("INSERT INTO action_board VALUES(?,?,?,?,?,?)", (a.get("stage"), int(a.get("priority") or 0), a.get("target"), a.get("task"), a.get("reason"), a.get("linked")))
        con.execute("CREATE TABLE work_queue(queue_id TEXT, stage TEXT, priority INTEGER, status TEXT, target TEXT, category TEXT, task TEXT, reason TEXT, linked TEXT, done_definition TEXT)")
        for w in result.get("work_queue") or []:
            con.execute("INSERT INTO work_queue VALUES(?,?,?,?,?,?,?,?,?,?)", (w.get("queue_id"), w.get("stage"), int(w.get("priority") or 0), w.get("status"), w.get("target"), w.get("category"), w.get("task"), w.get("reason"), w.get("linked"), w.get("done_definition")))
        con.commit(); con.close()
        with open(path, "rb") as f:
            return f.read()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def build_report_notes(result: Dict[str, Any]) -> List[Dict[str, Any]]:
    notes: List[Dict[str, Any]] = []
    for t in result.get("transfers", [])[:30]:
        pr = "高" if int(t.get("score", 0)) >= 80 else "中"
        notes.append({
            "category": "資金移動候補",
            "priority": pr,
            "text": f"{t.get('from')} から {money(t.get('withdrawal'))} 出金。{t.get('to')} に {money(t.get('deposit'))} 入金。差額 {money(t.get('amount_diff'))}、日数差 {t.get('days_diff')}日。理由: {'、'.join(t.get('reasons') or [])}。",
        })
    for t in result.get("group_transfers", [])[:20]:
        notes.append({
            "category": "分割移動候補",
            "priority": "中",
            "text": f"{t.get('kind')} の資金移動候補。出金合計 {money(t.get('withdrawal_total'))}、入金合計 {money(t.get('deposit_total'))}、差額 {money(t.get('amount_diff'))}。理由: {'、'.join(t.get('reasons') or [])}。",
        })
    for x in result.get("near_thresholds", [])[:20]:
        notes.append({"category": "節目額直下", "priority": "中", "text": f"{x.get('date')} {x.get('name')} {x.get('kind')} {money(x.get('amount'))}。{x.get('message')}"})
    for x in result.get("unknown_sources", [])[:20]:
        notes.append({"category": "原資不明入金", "priority": "中", "text": f"{x.get('date')} {x.get('name')} に {money(x.get('amount'))} の大口入金。{x.get('message')}"})
    return notes


def to_tsv(rows: List[Dict[str, Any]], headers: List[Tuple[str, str]]) -> str:
    sio = io.StringIO()
    writer = csv.writer(sio, delimiter="\t", lineterminator="\n")
    writer.writerow([h for _, h in headers])
    for r in rows:
        writer.writerow([r.get(k, "") for k, _ in headers])
    return sio.getvalue()


def make_xlsx(sheets: Dict[str, List[List[Any]]]) -> bytes:
    def col(n: int) -> str:
        s = ""
        while n:
            n, rem = divmod(n - 1, 26)
            s = chr(65 + rem) + s
        return s

    def sheet_xml(rows: List[List[Any]]) -> str:
        body = []
        for r_idx, row in enumerate(rows, start=1):
            cells = []
            for c_idx, val in enumerate(row, start=1):
                ref = f"{col(c_idx)}{r_idx}"
                if val is None:
                    cells.append(f'<c r="{ref}"/>')
                elif isinstance(val, (int, float)) and not isinstance(val, bool) and math.isfinite(float(val)):
                    cells.append(f'<c r="{ref}"><v>{val}</v></c>')
                else:
                    text = xml_escape(str(val))
                    cells.append(f'<c r="{ref}" t="inlineStr"><is><t>{text}</t></is></c>')
            body.append(f'<row r="{r_idx}">{"".join(cells)}</row>')
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + \
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' + ''.join(body) + '</sheetData></worksheet>'

    names = list(sheets.keys())
    workbook_sheets = []
    workbook_rels = []
    content_overrides = [
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
    ]
    for i, name in enumerate(names, start=1):
        workbook_sheets.append(f'<sheet name="{xml_escape(name[:31])}" sheetId="{i}" r:id="rId{i}"/>')
        workbook_rels.append(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>')
        content_overrides.append(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')

    mem = io.BytesIO()
    with zipfile.ZipFile(mem, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' + ''.join(content_overrides) + '</Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + ''.join(workbook_sheets) + '</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(workbook_rels) + '</Relationships>')
        for i, name in enumerate(names, start=1):
            z.writestr(f'xl/worksheets/sheet{i}.xml', sheet_xml(sheets[name]))
    return mem.getvalue()


def analyze_payload(payload: Dict[str, Any], include_report: bool = False) -> Dict[str, Any]:
    raw = payload.get("raw") or {}
    settings = payload.get("settings") or {}
    input_mode = str(settings.get("inputMode") or settings.get("input_mode") or "partial")
    balance_mode = str(settings.get("balanceCheckMode") or settings.get("balance_check_mode") or "reference")
    if input_mode in ("partial", "一部抽出入力", "一部抽出") and balance_mode not in ("strict", "normal"):
        balance_mode = "reference"
    txs, issues = parse_transactions(raw.get("transaction"))
    family = parse_family(raw.get("family"))
    addresses = parse_addresses(raw.get("address"))
    th = get_thresholds(payload)
    invalid_ids = analysis_excluded_tx_ids(txs, issues)
    analysis_txs = filter_analysis_txs(txs, invalid_ids)
    issues.extend(analyze_balance(analysis_txs, balance_mode))
    transfers = find_transfers(analysis_txs, family, th)
    group_transfers = find_group_transfers(analysis_txs, family, th)
    near = find_near_thresholds(analysis_txs)
    patterns = find_annual_patterns(transfers)
    unknown_sources = find_unknown_sources(analysis_txs, transfers, th["unknown"])
    cash_withdrawals = find_cash_withdrawals(analysis_txs, th)
    same_account_offsets = find_same_account_offsets(analysis_txs, th)
    same_account_offset_tx_ids = sorted({txid for o in same_account_offsets for txid in (o.get("tx_ids") or [])})
    period_aggregations = find_period_aggregations(analysis_txs, th)
    timing_clusters = find_timing_clusters(analysis_txs, family, addresses, th)
    memo_signal_rows = memo_signals(analysis_txs)

    result: Dict[str, Any] = {
        "ok": True,
        "engine": APP_NAME,
        "schemaVersion": SCHEMA_VERSION,
        "createdAt": _dt.datetime.now().isoformat(timespec="seconds"),
        "summary": {
            "transaction_count": len(txs),
            "analysis_transaction_count": len(analysis_txs),
            "analysis_excluded_count": len(invalid_ids),
            "family_count": len(family.get("people") or []),
            "address_count": len(addresses),
            "issue_count": len(issues),
            "transfer_count": len(transfers),
            "group_transfer_count": len(group_transfers),
            "cash_withdrawal_count": len(cash_withdrawals),
            "same_account_offset_count": len(same_account_offsets),
            "period_aggregation_count": len(period_aggregations),
            "near_threshold_count": len(near),
            "annual_pattern_count": len(patterns),
            "unknown_source_count": len(unknown_sources),
            "deceased": family.get("deceased"),
            "inheritance_date": family.get("inheritance_date"),
            "input_mode": input_mode,
            "balance_check_mode": balance_mode,
        },
        "issues": issues,
        "transfers": transfers,
        "group_transfers": group_transfers,
        "near_thresholds": near,
        "annual_patterns": patterns,
        "unknown_sources": unknown_sources,
        "cash_withdrawals": cash_withdrawals,
        "same_account_offsets": same_account_offsets,
        "same_account_offset_tx_ids": same_account_offset_tx_ids,
        "period_aggregations": period_aggregations,
        "timing_clusters": timing_clusters,
        "memo_signals": memo_signal_rows,
        "analysis_excluded_tx_ids": sorted(invalid_ids),
        "normalized": {
            "transactions": [asdict(t) for t in txs[:5000]],
            "family": family,
            "addresses": addresses,
        },
    }
    profile = extraction_profile(txs, family, addresses, input_mode)
    profile["analysis_transaction_count"] = len(analysis_txs)
    profile["analysis_excluded_count"] = len(invalid_ids)
    gates = quality_gates(profile, family)
    priority_cards = build_priority_cards(result, analysis_txs, family, th)
    case_id = get_case_id(payload)
    review_summary = apply_case_reviews(case_id, priority_cards)
    extraction_cards = build_extraction_cards(priority_cards)
    extraction_plan = build_optimized_extraction_plan(extraction_cards)
    questionnaires = build_questionnaires(priority_cards)
    fact_matrix = build_fact_matrix(priority_cards)
    person_summaries = build_person_summaries(analysis_txs, transfers, priority_cards)
    card_bundles = build_card_bundles(priority_cards)
    evidence_gaps = build_evidence_gap_ranking(priority_cards)
    action_board = build_action_board(priority_cards, extraction_plan, evidence_gaps)
    input_guidance = build_input_guidance(txs, issues, family, same_account_offsets)
    enrich_card_plain_fields(priority_cards)
    primary_cards = build_primary_cards(priority_cards)
    work_queue = build_work_queue(primary_cards, extraction_plan, evidence_gaps, questionnaires, input_guidance)
    completion_dashboard = build_completion_dashboard(priority_cards, work_queue, evidence_gaps, extraction_plan)
    operation_navigator = build_operation_navigator(input_guidance, primary_cards, priority_cards, work_queue)
    review_warnings = build_review_warnings(priority_cards)
    scenario_pathways = build_scenario_pathways(priority_cards)
    previous_result = payload.get("previousResult") if isinstance(payload.get("previousResult"), dict) else None
    if not previous_result:
        try:
            previous_result = latest_case_result(case_id)
        except Exception:
            previous_result = None
    case_diff = build_case_diff({"priority_cards": priority_cards, "summary": result.get("summary"), "createdAt": result.get("createdAt")}, previous_result)
    brief = build_brief(result, priority_cards, profile, gates)
    brief.setdefault("summary", []).append(f"案件ID: {case_id}。分析保存を使うと次回から差分比較できます。")
    if case_diff.get("has_previous"):
        brief.setdefault("summary", []).append(case_diff.get("message", ""))
    result.update({
        "case_id": case_id,
        "extraction_profile": profile,
        "quality_gates": gates,
        "input_guidance": input_guidance,
        "primary_cards": primary_cards,
        "priority_cards": priority_cards,
        "extraction_cards": extraction_cards,
        "extraction_plan": extraction_plan,
        "questionnaires": questionnaires,
        "fact_matrix": fact_matrix,
        "person_summaries": person_summaries,
        "card_bundles": card_bundles,
        "evidence_gaps": evidence_gaps,
        "action_board": action_board,
        "work_queue": work_queue,
        "completion_dashboard": completion_dashboard,
        "operation_navigator": operation_navigator,
        "review_warnings": review_warnings,
        "handover_memo": build_handover_memo(case_id, result, completion_dashboard, work_queue, review_warnings),
        "scenario_pathways": scenario_pathways,
        "case_diff": case_diff,
        "review_summary": review_summary,
        "brief": brief,
    })
    result["summary"].update({"case_id": case_id, "priority_card_count": len(priority_cards), "bundle_count": len(card_bundles), "extraction_task_count": len(extraction_cards), "optimized_extraction_plan_count": len(extraction_plan), "questionnaire_count": len(questionnaires), "evidence_gap_count": len(evidence_gaps), "work_queue_count": len(work_queue), "operation_status": operation_navigator.get("status"), "review_warning_count": len(review_warnings), "未確認カード": review_summary.get("counts",{}).get("未確認",0), "保留カード": review_summary.get("counts",{}).get("保留",0), "確認済み等": review_summary.get("reviewed_count",0), "高優先未完了": completion_dashboard.get("high_open_count",0)})

    note_rows = build_report_notes(result)
    for c in priority_cards[:30]:
        note_rows.append({"category":"優先確認カード","priority":"高" if c.get("action_score",0)>=75 else "中","text":f"{c.get('card_id')} {c.get('title')}｜対象:{c.get('target')}｜金額:{money(c.get('amount'))}｜リスク:{c.get('risk_score')} 材料:{c.get('internal_consistency_score') or c.get('evidence_score')} 資料:{c.get('document_evidence_score')} 次:{c.get('action_score')}｜次:{c.get('next_action')}"})
    memo_lines = ["【Python補助エンジン 調査メモ素材】", f"作成日時: {result['createdAt']}", "", "■ 判定ブリーフ"]
    for line in brief.get("summary",[]): memo_lines.append("・"+line)
    memo_lines.append("")
    for n in note_rows[:80]:
        memo_lines.append(f"■ {n['category']}（重要度:{n['priority']}）")
        memo_lines.append(n["text"])
        memo_lines.append("")
    if not note_rows:
        memo_lines.append("現時点で強い調査メモ候補は検出されませんでした。")
    memo_lines.append("")
    memo_lines.append(result.get("handover_memo", ""))

    result["report"] = {
        "note_rows": note_rows,
        "memo_text": "\n".join(memo_lines),
        "tsv": {
            "作業ナビ": to_tsv(operation_navigator.get("steps") or [], [("order","順番"),("stage","区分"),("target","対象"),("task","作業"),("reason","理由"),("done_definition","終わりの条件")]),
            "入力検査": to_tsv(issues, [("severity","重要度"),("category","区分"),("location","場所"),("message","内容")]),
            "入力確認ガイド": to_tsv(input_guidance, [("guide_id","ID"),("level","重要度"),("where","場所"),("what","内容"),("fix","対応"),("priority","優先度")]),
            "上位確認カード": to_tsv(primary_cards, [("card_id","ID"),("card_key","安定ID"),("display_priority","確認順"),("review_status","判断"),("review_memo","判断メモ"),("extraction_status","追加抽出"),("document_status","資料"),("question_status","質問"),("done_status","完了"),("category","分類"),("plain_title","表示タイトル"),("target","対象"),("amount","金額"),("short_reason","理由"),("short_gap","不足"),("plain_next","次にやること"),("question","確認質問")]),
            "優先確認カード": to_tsv(priority_cards, [("card_id","ID"),("card_key","安定ID"),("review_status","判断"),("review_memo","判断メモ"),("extraction_status","追加抽出"),("document_status","資料"),("question_status","質問"),("done_status","完了"),("category","分類"),("title","タイトル"),("target","対象"),("amount","金額"),("risk_score","確認優先度"),("internal_consistency_score","材料"),("document_evidence_score","資料"),("action_score","対応順"),("hypothesis","仮説"),("next_action","次にやること"),("question","確認質問")]),
            "確認束ね": to_tsv(card_bundles, [("bundle_id","ID"),("target","対象"),("category","分類"),("card_count","件数"),("total_amount","合計額"),("max_action_score","最高優先度"),("missing_facts","不足"),("documents","資料"),("next_actions","対応順")]),
            "追加抽出指示": to_tsv(extraction_cards, [("task_id","ID"),("priority","優先度"),("target","対象"),("range_from","開始"),("range_to","終了"),("pick_fields","拾う項目"),("purpose","目的"),("linked_card","カード")]),
            "追加抽出統合計画": to_tsv(extraction_plan, [("plan_id","ID"),("priority","優先度"),("target","対象"),("range_from","開始"),("range_to","終了"),("days","日数"),("linked_cards","カード"),("purpose","目的")]),
            "資料不足ランキング": to_tsv(evidence_gaps, [("priority","優先度"),("gap","不足・資料"),("card_count","件数"),("max_action_score","最高優先度"),("total_amount","関連金額"),("linked_cards","カード")]),
            "作業ボード": to_tsv(action_board, [("stage","段階"),("priority","優先度"),("target","対象"),("task","作業"),("reason","理由"),("linked","関連")]),
            "未処理作業キュー": to_tsv(work_queue, [("queue_id","ID"),("stage","段階"),("priority","優先度"),("status","状態"),("target","対象"),("category","分類"),("task","作業"),("reason","理由"),("linked","関連"),("done_definition","完了条件")]),
            "判断注意": to_tsv(review_warnings, [("level","重要度"),("card_id","カード"),("status","判断"),("target","対象"),("message","内容")]),
            "人物別質問票": to_tsv(questionnaires, [("person","人物"),("risk_count","件数"),("max_action_score","最大優先度"),("questions","質問"),("documents","資料")]),
            "資金移動候補": to_tsv(transfers, [("score","スコア"),("from","出金側"),("to","入金側"),("withdrawal","出金額"),("deposit","入金額"),("amount_diff","差額"),("days_diff","日数差")]),
            "調査メモ": to_tsv(note_rows, [("category","分類"),("priority","重要度"),("text","本文")]),
        }
    }

    if include_report:
        sheets = {
            "総括": [["項目", "値"]] + [[k, v] for k, v in result["summary"].items()],
            "判定ブリーフ": [["区分","内容"]] + [["要約", x] for x in brief.get("summary",[])] + [["最初の作業", x] for x in brief.get("first_actions",[])] + [["注意", x] for x in brief.get("warnings",[])],
            "作業ナビ": [["項目","内容"]] + [["状態", operation_navigator.get("status")], ["メッセージ", operation_navigator.get("message")], ["注記", operation_navigator.get("note")]] + [[f"手順{st.get('order')}", f"{st.get('stage')}｜{st.get('target')}｜{st.get('task')}｜完了条件:{st.get('done_definition')}"] for st in operation_navigator.get("steps") or []],
            "品質ゲート": [["レベル", "項目", "内容"]] + [[g.get("level"), g.get("item"), g.get("message")] for g in gates],
            "入力確認ガイド": [["ID","重要度","場所","内容","対応","優先度"]] + [[g.get("guide_id"), g.get("level"), g.get("where"), g.get("what"), g.get("fix"), g.get("priority")] for g in input_guidance],
            "上位確認カード": [["ID","安定ID","確認順","判断","判断メモ","追加抽出","資料","質問","完了","分類","表示タイトル","対象","金額","理由","不足","次にやること","確認質問"]] + [[c.get("card_id"), c.get("card_key"), c.get("display_priority"), c.get("review_status"), c.get("review_memo"), c.get("extraction_status"), c.get("document_status"), c.get("question_status"), c.get("done_status"), c.get("category"), c.get("plain_title"), c.get("target"), c.get("amount"), c.get("short_reason"), c.get("short_gap"), c.get("plain_next"), c.get("question")] for c in primary_cards],
            "優先確認カード": [["ID","安定ID","判断","判断メモ","追加抽出","資料","質問","完了","分類","タイトル","対象","金額","確認優先度","材料","資料","対応順","仮説","支持材料","不足材料","次にやること","確認質問","必要資料"]] + [[c.get("card_id"), c.get("card_key"), c.get("review_status"), c.get("review_memo"), c.get("extraction_status"), c.get("document_status"), c.get("question_status"), c.get("done_status"), c.get("category"), c.get("title"), c.get("target"), c.get("amount"), c.get("risk_score"), c.get("internal_consistency_score") or c.get("evidence_score"), c.get("document_evidence_score"), c.get("action_score"), c.get("hypothesis"), " / ".join(c.get("supporting_facts") or []), " / ".join(c.get("missing_facts") or []), c.get("next_action"), c.get("question"), " / ".join(c.get("documents") or [])] for c in priority_cards],
            "確認束ね": [["ID","対象","分類","件数","合計額","最高リスク","最高材料","最高次アクション","主仮説","不足","資料","対応順","カード"]] + [[b.get("bundle_id"), b.get("target"), b.get("category"), b.get("card_count"), b.get("total_amount"), b.get("max_risk_score"), b.get("max_evidence_score"), b.get("max_action_score"), b.get("main_hypothesis"), b.get("missing_facts"), b.get("documents"), b.get("next_actions"), b.get("top_cards")] for b in card_bundles],
            "追加抽出指示": [["ID","優先度","対象","開始","終了","拾う項目","目的","カード"]] + [[e.get("task_id"), e.get("priority"), e.get("target"), e.get("range_from"), e.get("range_to"), e.get("pick_fields"), e.get("purpose"), e.get("linked_card")] for e in extraction_cards],
            "追加抽出統合計画": [["ID","優先度","対象","開始","終了","日数","カード数","カード","拾う項目","目的","注記"]] + [[p.get("plan_id"), p.get("priority"), p.get("target"), p.get("range_from"), p.get("range_to"), p.get("days"), p.get("card_count"), p.get("linked_cards"), p.get("pick_fields"), p.get("purpose"), p.get("note")] for p in extraction_plan],
            "資料不足ランキング": [["優先度","不足・必要資料","件数","最高優先度","関連金額","カード"]] + [[g.get("priority"), g.get("gap"), g.get("card_count"), g.get("max_action_score"), g.get("total_amount"), g.get("linked_cards")] for g in evidence_gaps],
            "作業ボード": [["段階","優先度","対象","作業","理由","関連"]] + [[a.get("stage"), a.get("priority"), a.get("target"), a.get("task"), a.get("reason"), a.get("linked")] for a in action_board],
            "未処理作業キュー": [["ID","段階","優先度","状態","対象","分類","作業","理由","関連","完了条件"]] + [[w.get("queue_id"), w.get("stage"), w.get("priority"), w.get("status"), w.get("target"), w.get("category"), w.get("task"), w.get("reason"), w.get("linked"), w.get("done_definition")] for w in work_queue],
            "完了ダッシュボード": [["項目","値"]] + [[k, (" / ".join(v) if isinstance(v, list) else json.dumps(v, ensure_ascii=False) if isinstance(v, dict) else v)] for k, v in completion_dashboard.items()],
            "判断注意": [["重要度","カード","判断","対象","内容"]] + [[w.get("level"), w.get("card_id"), w.get("status"), w.get("target"), w.get("message")] for w in review_warnings],
            "論点ルート": [["論点","件数","合計額","最高優先度","資料準備度","状態","支持","不足","次","カード"]] + [[s.get("scenario"), s.get("card_count"), s.get("total_amount"), s.get("max_action_score"), s.get("evidence_readiness"), s.get("status"), s.get("support"), s.get("missing"), s.get("next_step"), s.get("linked_cards")] for s in scenario_pathways],
            "前回差分": [["項目","値"]] + [["前回あり", case_diff.get("has_previous")], ["メッセージ", case_diff.get("message")], ["新規", case_diff.get("new_count")], ["消滅", case_diff.get("removed_count")], ["変動", case_diff.get("changed_count")]],
            "人物別質問票": [["人物","件数","最大優先度","質問","必要資料"]] + [[q.get("person"), q.get("risk_count"), q.get("max_action_score"), "\n".join(q.get("questions") or []), " / ".join(q.get("documents") or [])] for q in questionnaires],
            "事実マトリクス": [["カード","分類","対象","既知事実","不足事実","仮説","反証テスト","対応順"]] + [[f.get("card_id"), f.get("category"), f.get("target"), f.get("known_facts"), f.get("missing_facts"), f.get("hypothesis"), f.get("rebuttal_test"), f.get("next_action")] for f in fact_matrix],
            "人物別サマリー": [["人物","取引件数","入金総額","出金総額","カード件数","最大優先度","主な論点","対応順"]] + [[p.get("name"), p.get("transaction_count"), p.get("deposit_total"), p.get("withdrawal_total"), p.get("priority_card_count"), p.get("max_action_score"), p.get("top_issue"), p.get("next_action")] for p in person_summaries],
            "入力検査": [["重要度", "区分", "場所", "内容"]] + [[i.get("severity"), i.get("category"), i.get("location"), i.get("message")] for i in issues],
            "資金移動候補": [["スコア", "出金側", "入金側", "出金額", "入金額", "差額", "日数差", "理由"]] + [[t.get("score"), t.get("from"), t.get("to"), t.get("withdrawal"), t.get("deposit"), t.get("amount_diff"), t.get("days_diff"), " / ".join(t.get("reasons") or [])] for t in transfers],
            "現金出金候補": [["日付","氏名","金額","摘要","取扱店","機番","内容"]] + [[x.get("date"), x.get("name"), x.get("amount"), x.get("memo"), x.get("store"), x.get("machine"), x.get("message")] for x in cash_withdrawals],
            "期間小口集約": [["氏名","種別","開始","終了","件数","合計","内容"]] + [[x.get("name"), x.get("kind"), x.get("start_date"), x.get("end_date"), x.get("count"), x.get("total"), x.get("message")] for x in period_aggregations],
            "調査メモ": [["分類", "重要度", "本文"]] + [[n.get("category"), n.get("priority"), n.get("text")] for n in note_rows],
        }
        xlsx = make_xlsx(sheets)
        result["report"]["xlsx_name"] = "相続インサイト_Python補助調書_市販品質.xlsx"
        result["report"]["xlsx_base64"] = base64.b64encode(xlsx).decode("ascii")
        db_bytes = make_sqlite_result_db(result)
        result["report"]["sqlite_name"] = "相続インサイト_Python分析結果.sqlite"
        result["report"]["sqlite_base64"] = base64.b64encode(db_bytes).decode("ascii")
    return result


class Handler(BaseHTTPRequestHandler):
    server_version = "InheritanceInsightAssist/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write("[%s] %s\n" % (_dt.datetime.now().strftime("%H:%M:%S"), fmt % args))

    def _headers(self, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Insight-Token")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()

    def _send_bytes(self, content: bytes, content_type: str = "application/octet-stream", status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if content:
            self.wfile.write(content)

    def _serve_app_html(self) -> None:
        html_path = Path(__file__).resolve().with_name("souzoku_insight.html")
        if not html_path.exists():
            self._headers(500)
            self.wfile.write(json.dumps({"ok": False, "error": "souzoku_insight.html が見つかりません"}, ensure_ascii=False).encode("utf-8"))
            return
        self._send_bytes(html_path.read_bytes(), "text/html; charset=utf-8", 200)

    def do_OPTIONS(self) -> None:
        self._headers(204)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ("/", "/app", "/souzoku_insight.html"):
            self._serve_app_html()
        elif path == "/favicon.ico":
            self._send_bytes(b"", "image/x-icon", 204)
        elif path == "/health":
            self._headers(200)
            self.wfile.write(json.dumps({"ok": True, "name": APP_NAME, "time": _dt.datetime.now().isoformat(timespec="seconds"), "schemaVersion": SCHEMA_VERSION}, ensure_ascii=False).encode("utf-8"))
        elif path == "/case/list":
            self._headers(200)
            self.wfile.write(json.dumps({"ok": True, "cases": list_case_runs()}, ensure_ascii=False).encode("utf-8"))
        elif path == "/diagnostics":
            self._headers(200)
            self.wfile.write(json.dumps({"ok": True, "name": APP_NAME, "schemaVersion": SCHEMA_VERSION, "case_db": str(case_db_path()), "max_post_bytes": MAX_POST_BYTES, "python": sys.version.split()[0]}, ensure_ascii=False).encode("utf-8"))
        elif path == "/case/review/list":
            params = parse_qs(urlparse(self.path).query)
            case_id = normalize_case_id((params.get("case_id") or [""])[0])
            if not case_id:
                self._headers(400)
                self.wfile.write(json.dumps({"ok": False, "error": "case_id required"}, ensure_ascii=False).encode("utf-8"))
            else:
                self._headers(200)
                reviews = list(list_case_reviews(case_id).values())
                self.wfile.write(json.dumps({"ok": True, "case_id": case_id, "reviews": reviews}, ensure_ascii=False).encode("utf-8"))
        else:
            self._headers(404)
            self.wfile.write(json.dumps({"ok": False, "error": "not found"}, ensure_ascii=False).encode("utf-8"))

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
            if length > MAX_POST_BYTES:
                self._headers(413)
                self.wfile.write(json.dumps({"ok": False, "error": f"request too large: {length} bytes"}, ensure_ascii=False).encode("utf-8"))
                return
            body = self.rfile.read(length)
            payload = json.loads(body.decode("utf-8") if body else "{}")
            if not isinstance(payload, dict):
                raise ValueError("JSON root must be object")
            if path == "/analyze":
                result = analyze_payload(payload, include_report=False)
            elif path == "/report":
                result = analyze_payload(payload, include_report=True)
            elif path == "/case/save":
                result = analyze_payload(payload, include_report=False)
                save_info = save_case_run(get_case_id(payload), payload, result)
                result["case_save"] = save_info
            elif path == "/case/review/save":
                case_id = get_case_id(payload)
                result = save_case_reviews(case_id, payload.get("reviews") or [])
            elif path == "/case/diff":
                result = analyze_payload(payload, include_report=False)
            else:
                self._headers(404)
                self.wfile.write(json.dumps({"ok": False, "error": "not found"}, ensure_ascii=False).encode("utf-8"))
                return
            self._headers(200)
            self.wfile.write(json.dumps(result, ensure_ascii=False).encode("utf-8"))
        except json.JSONDecodeError as e:
            self._headers(400)
            self.wfile.write(json.dumps({"ok": False, "error": "JSONとして読めません", "detail": str(e)}, ensure_ascii=False).encode("utf-8"))
        except ValueError as e:
            self._headers(400)
            self.wfile.write(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8"))
        except Exception as e:
            self._headers(500)
            self.wfile.write(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8"))


def run_server(host: str = "127.0.0.1", port: int = DEFAULT_PORT, open_browser: bool = False) -> None:
    httpd = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}/"
    print(f"{APP_NAME} を起動しました: {url}")
    print("ブラウザで上記URLを開いてください。終了は Ctrl+C。")
    if open_browser:
        def _open() -> None:
            try:
                webbrowser.open(url)
            except Exception:
                pass
        threading.Timer(0.8, _open).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n終了します。")
    finally:
        httpd.server_close()


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=APP_NAME)
    parser.add_argument("--server", action="store_true", help="ローカル連携サーバーとして起動")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--open", action="store_true", help="起動後にブラウザを開く")
    parser.add_argument("--input", help="HTMLから出力した投入JSON")
    parser.add_argument("--output", help="分析結果JSONの保存先")
    parser.add_argument("--xlsx", help="Excel調書の保存先")
    args = parser.parse_args(argv)

    if args.server or not args.input:
        run_server(args.host, args.port, open_browser=args.open)
        return 0

    with open(args.input, "r", encoding="utf-8") as f:
        payload = json.load(f)
    result = analyze_payload(payload, include_report=bool(args.xlsx))
    out_path = args.output or "python_assist_result.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    if args.xlsx:
        b64 = result.get("report", {}).get("xlsx_base64")
        if b64:
            with open(args.xlsx, "wb") as f:
                f.write(base64.b64decode(b64))
    print(out_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
