@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "APP=%~dp0souzoku_insight_app.py"
set "DATA_DIR=%~dp0souzoku_insight_data"
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>nul
if not exist "%APP%" exit /b 1
call :FIND_PYTHON
if errorlevel 1 exit /b 1
call :RUN_PY "%APP%" --open-when-ready --port 39876 --wait-seconds 3 > "%DATA_DIR%\reopen_app.log" 2> "%DATA_DIR%\reopen_app_error.log"
exit /b %ERRORLEVEL%
:FIND_PYTHON
set "PY_MODE="
set "PYTHON_EXE="
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY_MODE=PYLAUNCHER"
  exit /b 0
)
for %%C in (python python3) do (
  for /f "delims=" %%P in ('where %%C 2^>nul') do (
    "%%P" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
    if not errorlevel 1 (
      set "PY_MODE=PYTHON"
      set "PYTHON_EXE=%%P"
      exit /b 0
    )
  )
)
exit /b 1
:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" (
  py -3 %*
) else (
  "%PYTHON_EXE%" %*
)
exit /b %ERRORLEVEL%
