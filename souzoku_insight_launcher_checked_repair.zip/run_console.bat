@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Souzoku Insight console launcher
echo ========================================
echo Souzoku Insight console launcher
echo ========================================
echo.
echo This keeps errors visible.
echo.
call "%~dp0start_console.bat"
echo.
echo Check the message above.
pause
