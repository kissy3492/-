相続インサイト Python安定版セット

■最重要：起動方法
この版では、HTMLを直接ダブルクリックして使う方式をやめ、PythonサーバーがHTML画面とAPIを同時に配信します。
必ず start_engine.bat を起動してください。

Edgeが自動で開かない場合は、start_engine.bat の黒い画面を閉じずに、Edgeで次を開いてください。
http://127.0.0.1:8765/

■ファイル
- souzoku_insight.html : 画面本体。通常は直接開かず、Pythonサーバーから表示します。
- insight_engine.py : Python補助エンジン
- start_engine.bat : 起動用。これを実行します。
- check_gate.py : 検証ゲート
- README.txt : この説明
- SHA256.txt : 整合性確認用

■使い方
1. ZIPを任意のフォルダへ展開します。
2. check_gate.py を実行し、ALL OKを確認します。
3. start_engine.bat を起動します。
4. Edgeで http://127.0.0.1:8765/ が開きます。開かない場合は手入力してください。
5. 画面の「接続確認」を押します。
6. 入力後に「Pythonで分析」を実行します。

■終了方法
start_engine.bat の黒い画面で Ctrl+C を押すか、画面を閉じます。

■注意
- Python 3 が必要です。
- 業務データはローカルPC内で処理されます。
- 案件DB保存を使うと、同じフォルダに insight_case_db.sqlite が作成されます。
- 実行中は start_engine.bat の黒い画面を閉じないでください。
