@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "URL_FILE=%~dp0souzoku_insight_data\current_url.txt"
set "PORT=39876"
set "APP_URL="
if exist "%URL_FILE%" set /p APP_URL=<"%URL_FILE%"
if not "%APP_URL%"=="" (
  for /f "tokens=3 delims=:" %%A in ("%APP_URL%") do set "REST=%%A"
  for /f "tokens=1 delims=/" %%B in ("%REST%") do set "PORT=%%B"
)
echo Stopping Souzoku Insight on port %PORT% ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$port=[int]$env:PORT; $conns=Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue; if(-not $conns){Write-Host 'No running server was found.'; exit 0}; foreach($c in $conns){try{Stop-Process -Id $c.OwningProcess -Force -ErrorAction Stop; Write-Host ('Stopped process ' + $c.OwningProcess)}catch{Write-Host ('Failed to stop process ' + $c.OwningProcess + ': ' + $_.Exception.Message)}}"
echo Done.
pause
exit /b 0
