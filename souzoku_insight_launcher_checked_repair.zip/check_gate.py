# -*- coding: utf-8 -*-
from __future__ import annotations
import ast, base64, hashlib, importlib.util, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.request, urllib.error, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
APP=ROOT/'souzoku_insight_app.py'; SHA=ROOT/'SHA256.txt'
ALLOWED={'souzoku_insight_app.py','start.bat','START_HERE.cmd','start_hidden.vbs','silent_worker.cmd','STOP_SERVER.cmd','start_console.bat','OPEN_THIS.html','STANDALONE.html','open_app.bat','run_console.bat','diagnose.bat','check_gate.py','README.txt','README_JA.html','SHA256.txt','REOPEN_APP.cmd','open_existing.cmd','reopen_hidden.vbs','RESET_AND_START.cmd'}
TMPDIR_OBJ=tempfile.TemporaryDirectory()
os.environ['IH_APP_DATA_DIR']=str(Path(TMPDIR_OBJ.name)/'appdata')

def ok(m): print('[OK]',m)
def ng(m): print('[NG]',m); raise SystemExit(1)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load():
    spec=importlib.util.spec_from_file_location('souzoku_integrated_gate', APP)
    mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod); return mod

def cleanup_artifacts():
    import shutil
    for p in list(ROOT.rglob('__pycache__')):
        shutil.rmtree(p, ignore_errors=True)
    for p in ROOT.rglob('*.pyc'):
        try: p.unlink()
        except OSError: pass
    for p in ROOT.glob('_gate_*'):
        if p.is_file():
            try: p.unlink()
            except OSError: pass
    for p in ROOT.glob('*.sqlite'):
        if p.name.startswith('souzoku_insight') or p.name.startswith('_gate'):
            try: p.unlink()
            except OSError: pass
    data_dir = ROOT / 'souzoku_insight_data'
    if data_dir.exists():
        shutil.rmtree(data_dir, ignore_errors=True)


def dist_clean():
    files={p.name for p in ROOT.iterdir() if p.is_file()}
    if files!=ALLOWED: ng('配布ファイル不正: '+str(sorted(files)))
    for p in ROOT.rglob('*'):
        if any(x=='__pycache__' for x in p.parts) or p.suffix in {'.pyc','.sqlite','.log','.jsonl'} or p.name.startswith('_gate_'):
            ng('不要物混入: '+str(p.relative_to(ROOT)))
    listed={}
    for line in SHA.read_text(encoding='utf-8').splitlines():
        if '  ' in line:
            h,n=line.split('  ',1); listed[n]=h
    if set(listed.keys()) != (ALLOWED-{'SHA256.txt'}): ng('SHA256対象不正: '+str(sorted(listed.keys())))
    for name in ALLOWED-{'SHA256.txt'}:
        if listed.get(name)!=sha(ROOT/name): ng('SHA256不一致: '+name)
    ok('配布フォルダ浄化・SHA256')

def payload(mod, rows, fam_rows=None):
    fam = fam_rows if fam_rows is not None else [["被","相続人","被相続人","","2026-01-15","","","",""],["長","男","長男","","2026-01-15","","",'',""]]
    return {"caseId":"gate_case", "raw": {"transaction": [mod.TX_COLUMNS] + rows, "family": [mod.FAMILY_COLUMNS] + fam, "address": [mod.ADDRESS_COLUMNS]}, "settings": {}}

def analyze(mod, rows, fam_rows=None): return mod.analyze_payload(payload(mod, rows, fam_rows), include_report=False)
def contains_guidance(r, word): return any(word in json.dumps(g, ensure_ascii=False) for g in r.get('input_guidance', []))

def rule_tests(mod):
    r=analyze(mod, [['A','B','被相続人','普通','1','','','1000000','','','','ATM','']])
    if not any('日付が空欄' in x.get('message','') for x in r.get('issues', [])): ng('日付空欄＋金額ありの入力確認が出ません')
    if r.get('priority_cards'): ng('日付空欄＋金額ありが確認カード化しています')
    r=analyze(mod, [['A','B','','普通','1','2026-01-01','','1000000','','','','ATM','']])
    if not any('氏名が空欄' in x.get('message','') for x in r.get('issues', [])): ng('氏名空欄＋金額ありの入力確認が出ません')
    if r.get('priority_cards') or r.get('primary_cards'): ng('氏名空欄＋金額ありが確認カード化しています')
    r=analyze(mod, [['','','被相続人','普通','','2026-01-01','','1000000','','','','ATM',''], ['A','B','長男','普通','2','2026-01-01','','','1000000','','','','']])
    if not any(x.get('category') == '口座情報' for x in r.get('issues', [])): ng('口座情報不足が入力確認に出ません')
    if r.get('operation_navigator',{}).get('status') != '入力確認を先に処理': ng('口座情報不足時に作業ナビが入力確認を優先しません')
    if r.get('primary_cards'): ng('口座情報不足の取引が上位確認カードに出ています')
    steps = r.get('operation_navigator',{}).get('steps') or []
    step_keys = [(x.get('stage'), x.get('target'), x.get('task')) for x in steps]
    if len(step_keys) != len(set(step_keys)): ng('作業ナビに重複ステップがあります')
    r=analyze(mod, [['A','B','被相続人','普通','1','2026-01-01','25:99','1000000','','','','ATM','']])
    if not any(x.get('category') == '時刻' for x in r.get('issues', [])): ng('異常時刻が入力確認に出ません')
    r=analyze(mod, [['A','B','被相続人','普通','1','2026-01-01','','1000000','','','','ATM',''],['A','B','被相続人','普通','1','2026-01-01','','1000000','','','','ATM','']])
    if not contains_guidance(r, '重複') and not any(x.get('category') == '重複' for x in r.get('issues', [])): ng('重複行が入力確認に出ません')
    if r.get('priority_cards'): ng('重複行が確認カード化しています')
    rows=[['A','B','被相続人','普通','1','2026-01-01','09:00','1000000','','店','機','ATM',''],['A','B','長男','普通','2','2026-01-01','10:00','','1000000','店','機','振込',''],['A','B','長男','普通','2','2026-02-01','','','600000','','','給与','']]
    r=analyze(mod, rows)
    if not r.get('primary_cards'): ng('別口座間移動が上位カードに出ません')
    txt=json.dumps(r.get('primary_cards',[])+r.get('work_queue',[]), ensure_ascii=False)
    if '給与' in txt: ng('通常収入系が上位表示に混入しています')
    keys=[c.get('card_key') for c in r.get('priority_cards',[]) if c.get('card_key')]
    if len(keys)!=len(set(keys)): ng('card_key重複')
    # package direct
    res = mod.analyze_payload(payload(mod, rows), include_report=True)
    pname, pbytes = mod.make_analysis_package(payload(mod, rows), res)
    if not pname.endswith('.zip') or len(pbytes) < 1000: ng('案件パッケージ生成不正')
    with zipfile.ZipFile(__import__('io').BytesIO(pbytes)) as z:
        names=set(z.namelist())
        for need in ['manifest.json','input_payload.json','analysis_result.json','report.xlsx','analysis.sqlite','readme.txt']:
            if need not in names: ng('案件パッケージ不足: '+need)
        if not any('上位確認カード.tsv' in n for n in names): ng('案件パッケージTSV名の長音が保持されていません')
        if any('_ド.tsv' in n or '_ュ_' in n for n in names): ng('案件パッケージTSV名が崩れています')
    ok('分析ルール・入力安全・パッケージ')

def html_tests(mod):
    html=base64.b64decode(mod.APP_HTML_B64.encode('ascii')).decode('utf-8')
    scripts=re.findall(r'<script[^>]*>(.*?)</script>', html, flags=re.S|re.I)
    with tempfile.TemporaryDirectory() as td:
        for i,sc in enumerate(scripts):
            p=Path(td)/f'script_{i:03d}.js'; p.write_text(sc, encoding='utf-8')
            res=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
            if res.returncode: ng(f'HTML JS構文 script {i}: {res.stderr[:200]}')
    if 'Python補助エンジン' in html: ng('旧称がHTMLに残っています')
    for needle in ['ihIntegratedCommaSettings','案件パッケージ保存','監査ログ','自己診断','保存データ確認','運用データバックアップ','location.origin','X-Insight-Token']:
        if needle not in html: ng('統合UI不足: '+needle)
    for needle in ['1,000,000','500,000','100,000']:
        if needle not in html: ng('カンマ付き初期値不足: '+needle)
    # 既存HTML主要機能保持チェック。統合機能追加時に既存の入力・通常分析・出力導線を消さないため。
    legacy_needles = [
        'gridToRawData', 'parseTransactionData', 'parseFamilyData', 'parseAddressData',
        'analyzeData', 'familyGrid', 'addressGrid', 'analysisContainer', 'exportPanel',
        'openExportPanel', 'buildPrintableReport', 'doPrint'
    ]
    missing = [x for x in legacy_needles if x not in html]
    if missing: ng('既存機能保持チェック不足: '+','.join(missing))
    ok(f'HTML JavaScript構文 {len(scripts)}本・統合UI・既存機能保持')

def http_tests(mod):
    s=socket.socket(); s.bind(('127.0.0.1',0)); port=s.getsockname()[1]; s.close()
    th=threading.Thread(target=mod.run_server, kwargs={'host':'127.0.0.1','port':port,'open_browser':False}, daemon=True); th.start(); time.sleep(.8)
    def get(path): return urllib.request.urlopen(f'http://127.0.0.1:{port}{path}', timeout=8).read()
    html=get('/').decode('utf-8')
    mt=re.search(r'<meta name="ih-token" content="([^"]+)">', html)
    token = mt.group(1) if mt else ''
    if not token: ng('画面トークンがHTMLに埋め込まれていません')
    def post(path, obj):
        req=urllib.request.Request(f'http://127.0.0.1:{port}{path}', data=json.dumps(obj,ensure_ascii=False).encode('utf-8'), headers={'Content-Type':'application/json','X-Insight-Token':token}, method='POST')
        return urllib.request.urlopen(req, timeout=10).read()
    if '相続インサイト 統合分析版' not in html: ng('統合HTML配信不正')
    if '単体起動モード' in html or '単体ファイル表示中' in html:
        ng('Python起動時に単体版表示が残っています')
    for ep in ['/health','/app/info','/diagnostics','/selftest','/audit/list','/data/status']:
        j=json.loads(get(ep).decode('utf-8'))
        if not j.get('ok'): ng(ep+' 不正')
        if ep in ['/health','/app/info','/diagnostics'] and j.get('app_id') != 'souzoku_insight_integrated_local_checked': ng(ep+' app_id不正')
    try:
        req0=urllib.request.Request(f'http://127.0.0.1:{port}/analyze', data=json.dumps({}).encode('utf-8'), headers={'Content-Type':'application/json'}, method='POST')
        urllib.request.urlopen(req0,timeout=5).read(); ng('トークンなしPOSTが拒否されません')
    except urllib.error.HTTPError as e:
        if e.code != 403: ng('トークンなしPOSTのHTTPコード不正')
    bad={'case_id':'gate_case','reviews':[{'card_key':'x','review_status':'採用','status':'採用','done_status':'完了','review_memo':'理由','memo':'理由','extraction_status':'不要','document_status':'不要','question_status':'不要'}]}
    req=urllib.request.Request(f'http://127.0.0.1:{port}/case/review/save', data=json.dumps(bad,ensure_ascii=False).encode('utf-8'), headers={'Content-Type':'application/json','X-Insight-Token':token}, method='POST')
    try:
        urllib.request.urlopen(req,timeout=5).read(); ng('採用＋完了が拒否されません')
    except urllib.error.HTTPError as e:
        if e.code!=400: ng('状態不整合HTTPコード不正')
    sample=payload(mod, [['A','B','被相続人','普通','1','2026-01-01','09:00','1000000','','店','機','ATM',''],['A','B','長男','普通','2','2026-01-01','10:00','','1000000','店','機','振込','']])
    pj=json.loads(post('/package', sample).decode('utf-8'))
    if not pj.get('ok') or not pj.get('package_base64'): ng('/package 不正')
    dbk=json.loads(post('/data/backup', sample).decode('utf-8'))
    if not dbk.get('ok') or not dbk.get('backup_base64'): ng('/data/backup 不正')
    if not json.loads(get('/audit/list').decode('utf-8')).get('events'): ng('監査ログが記録されていません')
    if not mod._probe_existing_app('127.0.0.1', port): ng('既存起動検出が機能していません')
    class DummyHandler(__import__('http.server').server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b'{"ok":true,"error":"unauthorized"}')
        def log_message(self, *args): pass
    ds=socket.socket(); ds.bind(('127.0.0.1',0)); dport=ds.getsockname()[1]; ds.close()
    dummy=__import__('http.server').server.ThreadingHTTPServer(('127.0.0.1', dport), DummyHandler)
    threading.Thread(target=dummy.serve_forever, daemon=True).start(); time.sleep(.1)
    try:
        if mod._probe_existing_app('127.0.0.1', dport): ng('別ローカルサーバーを誤検出しています')
    finally:
        dummy.shutdown(); dummy.server_close()
    current_url = Path(os.environ.get('IH_APP_DATA_DIR', '')) / 'current_url.txt'
    if not current_url.exists() or f'http://127.0.0.1:{port}/' not in current_url.read_text(encoding='utf-8', errors='ignore'):
        ng('起動URL記録が作成されていません')
    ok('HTTP/API・統合機能')

def main():
    cleanup_artifacts()
    dist_clean()
    bat = (ROOT/'start.bat').read_text(encoding='ascii', errors='strict')
    start_here = (ROOT/'START_HERE.cmd').read_text(encoding='ascii', errors='strict')
    worker = (ROOT/'silent_worker.cmd').read_text(encoding='ascii', errors='strict')
    vbs = (ROOT/'start_hidden.vbs').read_text(encoding='ascii', errors='strict')
    console_bat = (ROOT/'start_console.bat').read_text(encoding='ascii', errors='strict')
    if 'wscript.exe' not in bat or 'start_hidden.vbs' not in bat: ng('start.bat is not hidden launcher')
    if 'wscript.exe' not in start_here or 'start_hidden.vbs' not in start_here: ng('START_HERE.cmd is not hidden launcher')
    if 'shell.Run' not in vbs or ', 0, False' not in vbs or 'OPEN_THIS.html' not in vbs: ng('VBS hidden launch/helper open is invalid')
    if '--server' not in worker or '--serve ' in worker: ng('silent_worker launch argument is invalid')
    if '--startup-check' not in worker: ng('silent_worker lacks startup check')
    if 'call :START_OPENER' in worker:
        ng('silent_worker still opens duplicate browser helper')
    if 'call :RUN_PY "%APP%" --server --port 39876' not in worker:
        ng('silent_worker does not start the server directly')
    if '--server' not in console_bat or '--startup-check' not in console_bat: ng('start_console.bat is not full troubleshooting launcher')
    if 'cmd /k "cd /d "%~dp0"' in worker or 'start "相続インサイト サーバー"' in worker:
        ng('fragile nested launcher remains')
    if 'current_url.txt' not in (ROOT/'open_app.bat').read_text(encoding='ascii', errors='strict'):
        ng('open_app.bat lacks URL reader')
    if not (ROOT/'OPEN_THIS.html').exists(): ng('OPEN_THIS.html missing')
    if not (ROOT/'STANDALONE.html').exists(): ng('STANDALONE.html missing')
    if 'souzoku_insight_app' not in (ROOT/'RESET_AND_START.cmd').read_text(encoding='ascii', errors='strict'):
        ng('RESET_AND_START.cmd does not target app process')
    if '単体ファイル表示中' not in (ROOT/'STANDALONE.html').read_text(encoding='utf-8', errors='ignore'):
        ng('STANDALONE.html mode banner missing')
    for helper in ['START_HERE.cmd','RESET_AND_START.cmd','start_hidden.vbs','silent_worker.cmd','STOP_SERVER.cmd','start_console.bat','open_app.bat','run_console.bat','diagnose.bat','REOPEN_APP.cmd','open_existing.cmd','reopen_hidden.vbs']:
        if not (ROOT/helper).exists(): ng(helper + ' missing')
    for helper in ['START_HERE.cmd','RESET_AND_START.cmd','start.bat','start_hidden.vbs','silent_worker.cmd','STOP_SERVER.cmd','start_console.bat','open_app.bat','run_console.bat','diagnose.bat','README.txt','REOPEN_APP.cmd','open_existing.cmd','reopen_hidden.vbs']:
        (ROOT/helper).read_text(encoding='ascii', errors='strict')
    for p in ROOT.iterdir():
        if any(ord(ch) > 127 for ch in p.name): ng('non-ASCII filename: '+p.name)
    open_html = (ROOT/'OPEN_THIS.html').read_text(encoding='utf-8')
    if 'MAX_WAIT_MS=45000' not in open_html or 'setTimeout(()=>scan(false), 1200)' not in open_html:
        ng('OPEN_THIS.html retry loop missing')
    if 'souzoku_insight_integrated_local_checked' not in open_html:
        ng('OPEN_THIS.html app id stale')
    m = re.search(r'<script[^>]*>(.*?)</script>', open_html, flags=re.S|re.I)
    if not m: ng('OPEN_THIS.html script missing')
    with tempfile.NamedTemporaryFile('w', suffix='.js', encoding='utf-8', delete=False) as tf:
        tf.write(m.group(1)); tmp_js=tf.name
    try:
        res=subprocess.run(['node','--check',tmp_js],capture_output=True,text=True)
        if res.returncode: ng('OPEN_THIS.html JS構文: '+res.stderr[:200])
    finally:
        try: Path(tmp_js).unlink()
        except OSError: pass
    try: ast.parse(APP.read_text(encoding='utf-8'))
    except SyntaxError as e: ng('Python構文: '+str(e))
    app_src = APP.read_text(encoding='utf-8')
    if 'if args.open_when_ready:' not in app_src or 'return wait_open_app(args.host, args.port, args.wait_seconds)' not in app_src:
        ng('CLI --open-when-ready is not wired to wait_open_app')
    if app_src.find('if args.open_when_ready:') > app_src.find('if args.server or not args.input:'):
        ng('CLI --open-when-ready is checked after server fallback')
    if 'APP_ID = "souzoku_insight_integrated_local_checked"' not in app_src:
        ng('APP_ID was not refreshed')
    mod=load()
    sc = mod.startup_check()
    if not sc.get('ok'): ng('起動前診断が失敗します: '+json.dumps(sc, ensure_ascii=False))
    html_tests(mod); rule_tests(mod); http_tests(mod); cleanup_artifacts(); dist_clean(); print('ALL OK')
if __name__=='__main__':
    try: main()
    finally: TMPDIR_OBJ.cleanup()
