Souzoku Insight integrated launcher

Start here:
1. Right-click the ZIP and choose Extract All.
2. Open the extracted folder.
3. Double-click START_HERE.cmd.
4. The black console window closes automatically after launch.
5. OPEN_THIS.html opens and waits until the local app is ready, then redirects to it.
6. If you close only the Edge tab, run START_HERE.cmd again. It will reopen the already-running app.
7. To stop the hidden local server, run STOP_SERVER.cmd.
8. If older test servers are left behind, run RESET_AND_START.cmd once.

Reopen:
- START_HERE.cmd can be used both for first start and reopen.
- REOPEN_APP.cmd only reopens an already-running server. It does not start a new one.
- OPEN_THIS.html retries for about 45 seconds and can find the running app safely.


Screen layout after launch:
- Use the normal input area and press the single Analyze button.
- The first result tab is the integrated checklist. It contains the ordinary HTML summary and the confirmation navigator in one place.
- Case DB, review save, Excel report, package save, audit log, and diagnostics are grouped under Case management / save / output, and also in the left menu.
- There is no separate Python analysis screen to inspect first.

Fallback:
- STANDALONE.html opens without Python.
- Standalone mode cannot use the Python-linked case DB, audit log, Excel/SQLite package output.

Troubleshooting:
- If START_HERE.cmd does not open the screen, open OPEN_THIS.html.
- If it still fails, run run_console.bat to keep errors visible.
- Then run diagnose.bat.
- Hidden-launch logs are stored in souzoku_insight_data.
- If Python is not available, use STANDALONE.html.

Files:
START_HERE.cmd      Recommended hidden launcher and reopen entry
RESET_AND_START.cmd Stops old app processes, then starts cleanly
start.bat           Same hidden launcher
start_hidden.vbs    Runs the worker without a visible console
silent_worker.cmd   Hidden server worker
REOPEN_APP.cmd      Reopens an already-running server
open_existing.cmd   Hidden reopen helper worker
reopen_hidden.vbs   Hidden reopen helper
STOP_SERVER.cmd     Stops the hidden local server
start_console.bat   Visible launcher for troubleshooting
run_console.bat     Visible launcher wrapper
open_app.bat        Opens the current local URL
OPEN_THIS.html      Helper page to find the running server
STANDALONE.html     Fallback single HTML

Default local port: 39876 with fallback through 39886.
If you see {"ok":false,"error":"unauthorized"}, you are looking at another local server, not this app. Open OPEN_THIS.html.



UI refinement notes:
- A sticky integrated command center is placed near the top of the screen.
- Normal flow is transaction input -> family input -> analyze -> integrated checklist -> package save.
- Python-linked navigator, case DB, Excel report, audit log, and diagnostics are grouped into the command center and integrated checklist instead of separate screens.
- Use Focus on results to hide input areas temporarily while reviewing results.
- All command center buttons are color-coded consistently.
- Input, settings, results, package, and export buttons scroll to the target area while the command center remains visible.
