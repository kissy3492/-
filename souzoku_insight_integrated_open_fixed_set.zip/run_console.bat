@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if not exist "souzoku_insight_app.py" (
  echo [ERROR] souzoku_insight_app.py が見つかりません。ZIPを展開してから実行してください。
  pause
  exit /b 1
)
where py >nul 2>nul
if not errorlevel 1 (
  py -3 souzoku_insight_app.py --server --open --port 8765
) else (
  python souzoku_insight_app.py --server --open --port 8765
)
echo.
echo 終了しました。上にエラーが出ている場合は、その内容を確認してください。
pause
