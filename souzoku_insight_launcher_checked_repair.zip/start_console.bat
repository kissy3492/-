@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "APP=%~dp0souzoku_insight_app.py"
set "DATA_DIR=%~dp0souzoku_insight_data"

echo ========================================
echo Souzoku Insight launcher
echo ========================================
echo.

if not exist "%APP%" (
  echo [ERROR] souzoku_insight_app.py was not found.
  echo Extract the ZIP first, then run START_HERE.cmd from the extracted folder.
  echo.
  pause
  exit /b 1
)
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>nul

call :FIND_PYTHON
if errorlevel 1 goto NO_PYTHON

echo [1] Python check
call :RUN_PY -c "import sys; print(sys.version.split()[0]); raise SystemExit(0 if sys.version_info >= (3,8) else 1)"
if errorlevel 1 goto BAD_PYTHON

echo.
echo [2] Startup check
call :RUN_PY "%APP%" --startup-check > "%DATA_DIR%\startup_check.json" 2> "%DATA_DIR%\startup_check_error.txt"
if errorlevel 1 (
  echo [ERROR] Startup check failed.
  echo See souzoku_insight_data\startup_check.json and startup_check_error.txt.
  echo.
  type "%DATA_DIR%\startup_check_error.txt" 2>nul
  pause
  exit /b 1
)
echo Startup check OK.

echo.
echo [3] Starting local server.
echo If Edge does not open automatically, copy the URL shown below into Edge.
echo Keep this black window open while using the app.
echo Press Ctrl+C in this window to stop the app.
echo.

start "" /min "%ComSpec%" /c "timeout /t 3 /nobreak >nul & call ""%~dp0open_app.bat"""
call :RUN_PY "%APP%" --server --port 39876 --open
set "EXITCODE=%ERRORLEVEL%"
echo.
echo Server stopped. Exit code: %EXITCODE%
echo If it did not open, run diagnose.bat.
pause
exit /b %EXITCODE%

:FIND_PYTHON
set "PY_MODE="
set "PYTHON_EXE="
py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
if not errorlevel 1 (
  set "PY_MODE=PYLAUNCHER"
  exit /b 0
)
for %%C in (python python3) do (
  for /f "delims=" %%P in ('where %%C 2^>nul') do (
    "%%P" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)" >nul 2>nul
    if not errorlevel 1 (
      set "PY_MODE=PYTHON"
      set "PYTHON_EXE=%%P"
      exit /b 0
    )
  )
)
exit /b 1

:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" (
  py -3 %*
) else (
  "%PYTHON_EXE%" %*
)
exit /b %ERRORLEVEL%

:NO_PYTHON
echo [ERROR] Python 3.8 or later was not found.
echo Use STANDALONE.html for the no-Python fallback.
echo Python-linked output will not be available in standalone mode.
pause
exit /b 1

:BAD_PYTHON
echo [ERROR] Python was found, but it is older than 3.8 or failed to start.
echo Use STANDALONE.html for the no-Python fallback.
pause
exit /b 1
