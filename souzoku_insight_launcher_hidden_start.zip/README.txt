Souzoku Insight integrated launcher

Start here:
1. Right-click the ZIP and choose Extract All.
2. Open the extracted folder.
3. Double-click START_HERE.cmd.
4. The black console window closes automatically after launch.
5. Edge should open automatically.
6. To stop the hidden local server, run STOP_SERVER.cmd.

Fallback:
- STANDALONE.html opens without Python.
- Standalone mode cannot use the Python-linked case DB, audit log, Excel/SQLite package output.

Troubleshooting:
- If START_HERE.cmd does not open the screen, run open_app.bat.
- If it still fails, run run_console.bat to keep errors visible.
- Then run diagnose.bat.
- Hidden-launch logs are stored in souzoku_insight_data.
- If Python is not available, use STANDALONE.html.

Files:
START_HERE.cmd    Recommended hidden launcher
start.bat         Same hidden launcher
start_hidden.vbs  Runs the worker without a visible console
silent_worker.cmd Hidden server worker
STOP_SERVER.cmd   Stops the hidden local server
start_console.bat Visible launcher for troubleshooting
run_console.bat   Visible launcher wrapper
open_app.bat      Opens the running local URL
diagnose.bat      Checks Python, syntax, startup, and gate tests
OPEN_THIS.html    Helper page to find the running server
STANDALONE.html   Fallback single HTML
