@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title 相続インサイト 診断
echo ========================================
echo 相続インサイト 診断
echo ========================================
echo.
set "APP=%~dp0souzoku_insight_app.py"
set "DATA_DIR=%~dp0souzoku_insight_data"
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>nul

where py >nul 2>nul
if not errorlevel 1 (
  set "PY_MODE=PYLAUNCHER"
) else (
  for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
  if not defined PYTHON_EXE (
    echo [ERROR] Python が見つかりません。
    pause
    exit /b 1
  )
  set "PY_MODE=PYTHON"
)

echo [1] Python確認
call :RUN_PY --version
if errorlevel 1 goto ERR

echo.
echo [2] アプリ構文確認
call :RUN_PY -m py_compile "%APP%"
if errorlevel 1 goto ERR

echo.
echo [3] 起動前診断
call :RUN_PY "%APP%" --startup-check
if errorlevel 1 goto ERR

echo.
echo [4] 検証ゲート
call :RUN_PY "%~dp0check_gate.py"
if errorlevel 1 goto ERR

echo.
echo 診断OKです。start.bat を実行してください。
pause
exit /b 0

:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" (
  py -3 %*
) else (
  "%PYTHON_EXE%" %*
)
exit /b %ERRORLEVEL%

:ERR
echo.
echo [ERROR] 診断で問題が出ました。上のエラー文を確認してください。
pause
exit /b 1
