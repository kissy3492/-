#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""相続インサイト Python最終再点検 検証ゲート

配布フォルダを汚さず、一時DB・一時ファイルで検証する。
"""
from __future__ import annotations
import base64, hashlib, importlib.util, json, os, re, shutil, sqlite3, subprocess, sys, tempfile, py_compile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
HTML = ROOT / "相続インサイト_Python最終再点検.html"
ENGINE = ROOT / "相続インサイト補助エンジン.py"
README = ROOT / "README_相続インサイト_Python最終再点検.txt"
BAT = ROOT / "Python補助エンジン起動.bat"
SHA = ROOT / "SHA256_最終再点検.txt"
ALLOWED = {HTML.name, ENGINE.name, README.name, BAT.name, SHA.name, Path(__file__).name}
FORBIDDEN_RE = re.compile(r"(__pycache__|\.pyc$|_gate_.*\.js$|案件DB\.sqlite$|\.log$|\.tmp$)")
BANNED_WORDS = ["税理士が", "最終判断は税理士", "素人", "アホ", "プロ並み", "簡単"]


def ok(msg): print(f"[OK] {msg}")
def ng(msg): raise AssertionError(msg)


def load_engine(tmpdb: Path):
    os.environ["IH_CASE_DB_PATH"] = str(tmpdb)
    spec = importlib.util.spec_from_file_location("ih_engine_gate", ENGINE)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["ih_engine_gate"] = mod
    spec.loader.exec_module(mod)  # type: ignore
    return mod


def payload(mod, tx_rows, fam_rows=None):
    return {"caseId": "GATE_CASE", "raw": {"transaction": [mod.TX_COLUMNS] + tx_rows, "family": [mod.FAMILY_COLUMNS] + (fam_rows or []), "address": [mod.ADDRESS_COLUMNS]}, "settings": {}}


def all_card_keys_unique(result):
    keys = [c.get("card_key") for c in result.get("priority_cards", []) if c.get("card_key")]
    return len(keys) == len(set(keys))


def test_distribution_clean():
    missing = [p.name for p in [HTML, ENGINE, README, BAT, SHA, Path(__file__)] if not (ROOT / p.name).exists()]
    if missing:
        ng("必要ファイルが不足しています: " + ", ".join(missing))
    files = [p for p in ROOT.iterdir() if p.is_file()]
    extras = [p.name for p in files if p.name not in ALLOWED]
    if extras:
        ng("許可外ファイルがあります: " + ", ".join(extras))
    bad = []
    for p in ROOT.rglob("*"):
        rel = str(p.relative_to(ROOT))
        if FORBIDDEN_RE.search(rel):
            bad.append(rel)
    if bad:
        ng("配布フォルダに一時/DB/キャッシュが混入しています: " + ", ".join(bad[:10]))
    ok("配布フォルダ浄化")


def test_sha():
    lines = [x.strip() for x in SHA.read_text(encoding="utf-8").splitlines() if x.strip()]
    got = {}
    for line in lines:
        h, name = line.split("  ", 1)
        got[name] = h
    expected = sorted(ALLOWED - {SHA.name})
    if sorted(got) != expected:
        ng("SHA対象が許可ファイル一式と一致しません")
    for name, h in got.items():
        actual = hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
        if actual != h:
            ng(f"SHA不一致: {name}")
    ok("SHA256整合性")


def test_python_and_html():
    with tempfile.NamedTemporaryFile(suffix=".pyc") as cf:
        py_compile.compile(str(ENGINE), cfile=cf.name, doraise=True)
    html = HTML.read_text(encoding="utf-8")
    readme = README.read_text(encoding="utf-8")
    for w in BANNED_WORDS:
        if w in html or w in readme:
            ng(f"表示文言に禁止語が残っています: {w}")
    scripts = re.findall(r"<script[^>]*>(.*?)</script>", html, flags=re.S|re.I)
    if len(scripts) < 1:
        ng("HTML内scriptを抽出できません")
    node = shutil.which("node")
    if node:
        with tempfile.TemporaryDirectory() as td:
            for i, code in enumerate(scripts):
                sp = Path(td) / f"script_{i:03d}.js"
                sp.write_text(code, encoding="utf-8")
                subprocess.run([node, "--check", str(sp)], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ok(f"Python構文・HTML JavaScript構文 {len(scripts)}本")


def test_analysis_rules(mod):
    fam = [["被", "相続人", "被相続人", "", "2026-01-15", "", "", "", ""], ["長", "男", "長男", "", "2026-01-15", "", "", "", ""], ["二", "男", "二男", "", "2026-01-15", "", "", "", ""]]
    # 日付エラー行は分析カードにしない
    r = mod.analyze_payload(payload(mod, [["A","B","山田太郎","普通","1","2026-13-01","","1000000","","","","ATM",""]], fam))
    if r["priority_cards"]:
        ng("日付エラー行から確認カードが生成されています")
    if r["operation_navigator"].get("status") != "入力確認を先に処理":
        ng("日付エラー時に作業ナビが入力確認を優先していません")
    # 日付空欄＋金額ありは警告し、分析カードにしない
    r = mod.analyze_payload(payload(mod, [["A","B","山田太郎","普通","1","","","1000000","","","","ATM",""]], fam))
    if not any("日付が空欄" in x.get("message", "") for x in r.get("issues", [])):
        ng("日付空欄＋金額ありの入力確認が出ていません")
    if r.get("priority_cards"):
        ng("日付空欄＋金額あり行から確認カードが生成されています")
    # 氏名空欄＋金額ありは警告し、上位カードにしない
    r = mod.analyze_payload(payload(mod, [["A","B","","普通","1","2026-01-01","","1000000","","","","ATM",""]], fam))
    if not any("氏名が空欄" in x.get("message", "") for x in r.get("issues", [])):
        ng("氏名空欄＋金額ありの入力確認が出ていません")
    if r.get("primary_cards") or r.get("priority_cards"):
        ng("氏名空欄＋金額あり行から確認カードが生成されています")
    # 時刻異常は警告に出す
    r = mod.analyze_payload(payload(mod, [["A","B","山田太郎","普通","1","2026-01-01","25:99","1000000","","","","ATM",""]], fam))
    if not any(x.get("category") == "時刻" for x in r.get("issues", [])):
        ng("異常時刻の入力確認が出ていません")
    # マイナス金額は警告/除外
    r = mod.analyze_payload(payload(mod, [["A","B","山田太郎","普通","1","2026-01-01","","-1000000","","","","ATM",""]], fam))
    if not any("マイナス" in x.get("message","") for x in r["issues"]):
        ng("マイナス金額の入力確認が出ていません")
    if r["priority_cards"]:
        ng("マイナス金額行から確認カードが生成されています")

    # 口座情報不足は入力確認へ出す。ただし分析は継続可能。
    r = mod.analyze_payload(payload(mod, [["","","被相続人","普通","","2026-01-01","","1000000","","","","ATM", ""],["A","B","長男","普通","2","2026-01-01","","","1000000","","","",""]], fam))
    if not any(x.get("category") == "口座情報" for x in r.get("issues", [])):
        ng("銀行・支店・口座番号不足の入力確認が出ていません")
    if r["operation_navigator"].get("status") != "入力確認を先に処理":
        ng("口座情報不足時に作業ナビが入力確認を優先していません")

    # 前提不足はナビ優先
    r = mod.analyze_payload(payload(mod, [["A","B","山田太郎","普通","1","2026-01-01","","1000000","","","","ATM",""]]))
    if r["operation_navigator"].get("status") != "入力確認を先に処理":
        ng("被相続人・相続開始日未設定時に作業ナビが入力確認を優先していません")
    # 通常収入は上位カードと作業キューに出さない
    r = mod.analyze_payload(payload(mod, [["A","B","長男","普通","2","2026-01-01","","","600000","","","給与",""]], fam))
    text = json.dumps({"primary": r.get("primary_cards"), "work": r.get("work_queue")}, ensure_ascii=False)
    if "給与" in text or "通常収入系" in text:
        ng("通常収入系が上位表示または作業キューに混入しています")
    # 同一口座同日同額は入力確認へ
    r = mod.analyze_payload(payload(mod, [["A","B","山田太郎","普通","1","2026-01-01","","1000000","","","","", ""],["A","B","山田太郎","普通","1","2026-01-01","","","1000000","","","",""]], fam))
    if any(c.get("category") in {"資金移動", "現金化", "入金原資", "節目額"} for c in r.get("primary_cards", [])):
        ng("同一口座内の同日同額取引が上位確認カードに出ています")
    if not r.get("input_guidance"):
        ng("同一口座内の同日同額取引が入力確認に出ていません")
    # 同一内容重複行は分析材料から外し、card_key重複を起こさない
    r = mod.analyze_payload(payload(mod, [
        ["A","B","被相続人","普通","1","2026-01-01","","1000000","","","","ATM", ""],
        ["A","B","被相続人","普通","1","2026-01-01","","1000000","","","","ATM", ""],
        ["A","B","長男","普通","2","2026-01-01","","","1000000","","","", ""],
        ["A","B","二男","普通","3","2026-01-01","","","1000000","","","", ""],
    ], fam))
    if not any("同一内容" in x.get("what", "") for x in r.get("input_guidance", [])):
        ng("同一内容重複行が入力確認に出ていません")
    if any(c.get("category") == "資金移動" for c in r.get("priority_cards", [])):
        ng("同一内容重複行を材料に資金移動カードが生成されています")
    if not all_card_keys_unique(r):
        ng("確認カードのcard_keyが重複しています")
    # 別口座間資金移動は上位に出る
    r = mod.analyze_payload(payload(mod, [["A","B","被相続人","普通","1","2026-01-01","","1000000","","","","ATM", ""],["A","B","長男","普通","2","2026-01-01","","","1000000","","","",""]], fam))
    if not r.get("primary_cards") or r["primary_cards"][0].get("category") != "資金移動":
        ng("別口座間の近接同額移動が上位カードの先頭に出ていません")
    if not all_card_keys_unique(r):
        ng("通常分析で確認カードのcard_keyが重複しています")
    # 行順変更で安定ID維持
    p1 = payload(mod, [["A","B","被相続人","普通","1","2026-01-01","","1000000","","","","ATM", ""],["A","B","長男","普通","2","2026-01-01","","","1000000","","","",""]], fam)
    p2 = payload(mod, [["Z","Z","参考","普通","9","2025-12-31","","10000","","","","", ""],["A","B","被相続人","普通","1","2026-01-01","","1000000","","","","ATM", ""],["A","B","長男","普通","2","2026-01-01","","","1000000","","","",""]], fam)
    k1 = mod.analyze_payload(p1)["primary_cards"][0]["card_key"]
    k2 = mod.analyze_payload(p2)["primary_cards"][0]["card_key"]
    if k1 != k2:
        ng("行追加で同一カードの安定IDが変わっています")
    ok("分析ルール・入力安全")


def test_review_validation_and_report(mod):
    for bad in [
        {"card_key":"x","status":"未確認","done_status":"完了"},
        {"card_key":"x","status":"採用","done_status":"完了","memo":"理由","extraction_status":"不要","document_status":"不要","question_status":"不要"},
    ]:
        try:
            mod.save_case_reviews("GATE_CASE", [bad])
            ng("APIが不整合な完了状態を保存しています: " + json.dumps(bad, ensure_ascii=False))
        except ValueError:
            pass
    # 完了可能な組み合わせは通る
    mod.save_case_reviews("GATE_CASE", [{"card_key":"ok1","status":"確認済","done_status":"完了","memo":"資料確認済。追加確認不要。","extraction_status":"不要","document_status":"不要","question_status":"不要"}])
    fam = [["被", "相続人", "被相続人", "", "2026-01-15", "", "", "", ""], ["長", "男", "長男", "", "2026-01-15", "", "", "", ""]]
    r = mod.analyze_payload(payload(mod, [["A","B","被相続人","普通","1","2026-01-01","","1000000","","","","ATM", ""],["A","B","長男","普通","2","2026-01-01","","","1000000","","","",""]], fam), include_report=True)
    rep = r.get("report") or {}
    if not rep.get("xlsx_base64") or not rep.get("sqlite_base64"):
        ng("ExcelまたはSQLite出力がありません")
    db = base64.b64decode(rep["sqlite_base64"])
    with tempfile.NamedTemporaryFile(suffix=".sqlite") as f:
        f.write(db); f.flush()
        con = sqlite3.connect(f.name)
        cols = [row[1] for row in con.execute("PRAGMA table_info(priority_cards)").fetchall()]
        for c in ["extraction_status", "document_status", "question_status", "done_status", "document_state_label"]:
            if c not in cols:
                ng(f"SQLite priority_cards に {c} がありません")
        con.close()
    ok("状態保存API・Excel/SQLite出力")


def main():
    before = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob("*"))
    test_distribution_clean()
    test_sha()
    test_python_and_html()
    with tempfile.TemporaryDirectory() as td:
        tmpdb = Path(td) / "case.sqlite"
        mod = load_engine(tmpdb)
        test_analysis_rules(mod)
        test_review_validation_and_report(mod)
    after = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob("*"))
    if before != after:
        ng("検証ゲート実行により配布フォルダが変化しました")
    print("ALL OK")

if __name__ == "__main__":
    main()
