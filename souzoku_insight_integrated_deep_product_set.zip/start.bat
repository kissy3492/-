@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "APP=souzoku_insight_app.py"
if not exist "%APP%" (
  echo [ERROR] %APP% が見つかりません。ZIPを展開したフォルダ内で start.bat を実行してください。
  pause
  exit /b 1
)
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY_CMD=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] Python が見つかりません。Python 3 をインストールしてから再実行してください。
    echo        py または python コマンドが使える必要があります。
    pause
    exit /b 1
  )
  set "PY_CMD=python"
)
echo 使用するPython:
%PY_CMD% --version
echo.
echo 起動します。ブラウザが開かない場合は、表示された http://127.0.0.1:ポート番号/ をEdgeで開いてください。
echo.
%PY_CMD% "%APP%" --server --open --port 8765
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo [ERROR] 起動に失敗しました。上のエラー内容を確認してください。
  echo Pythonの場所、ポート使用状況、ZIP展開先を確認してください。
)
pause
exit /b %RC%
