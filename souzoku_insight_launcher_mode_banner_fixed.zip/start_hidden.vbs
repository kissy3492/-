Option Explicit
Dim shell, fso, folder, worker
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
worker = fso.BuildPath(folder, "silent_worker.cmd")
shell.Run Chr(34) & worker & Chr(34), 0, False
