@echo off
setlocal
cd /d "%~dp0"
echo Starting Inheritance Insight local app...
echo.
echo Browser URL: http://127.0.0.1:8765/
echo Keep this window open while using the tool.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0insight_engine.py" --server --port 8765 --open
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python "%~dp0insight_engine.py" --server --port 8765 --open
  ) else (
    echo Python 3 was not found. Please install Python 3 and run again.
  )
)
pause
