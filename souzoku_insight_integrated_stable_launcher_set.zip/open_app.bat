@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
set "URL_FILE=%~dp0souzoku_insight_data\current_url.txt"
set "APP_URL="
if exist "%URL_FILE%" set /p APP_URL=<"%URL_FILE%"
if "%APP_URL%"=="" set "APP_URL=http://127.0.0.1:8765/"
echo 開くURL: %APP_URL%
start "" "%APP_URL%"
