Option Explicit
Dim shell, fso, folder, cmd
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
cmd = "cmd.exe /c " & Chr(34) & fso.BuildPath(folder, "open_existing.cmd") & Chr(34)
shell.Run cmd, 0, False
