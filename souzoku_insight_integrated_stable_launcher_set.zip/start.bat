@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"

title 相続インサイト 統合分析版
echo ========================================
echo 相続インサイト 統合分析版 起動
echo ========================================
echo.

set "APP=%~dp0souzoku_insight_app.py"
set "DATA_DIR=%~dp0souzoku_insight_data"
if not exist "%APP%" (
  echo [ERROR] souzoku_insight_app.py が見つかりません。
  echo ZIPを展開したフォルダ内で start.bat を実行してください。
  pause
  exit /b 1
)
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%" >nul 2>nul

call :FIND_PYTHON
if errorlevel 1 goto NO_PYTHON

echo [1] Python確認
call :RUN_PY --version
if errorlevel 1 goto NO_PYTHON

echo.
echo [2] 起動前診断
call :RUN_PY "%APP%" --startup-check > "%DATA_DIR%\startup_check.json" 2> "%DATA_DIR%\startup_check_error.txt"
if errorlevel 1 (
  echo [ERROR] 起動前診断で問題が出ました。
  echo.
  type "%DATA_DIR%\startup_check.json" 2>nul
  type "%DATA_DIR%\startup_check_error.txt" 2>nul
  echo.
  echo 詳細は souzoku_insight_data\startup_check.json を確認してください。
  pause
  exit /b 1
)
type "%DATA_DIR%\startup_check.json"

echo.
echo [3] サーバーを起動します。
echo Edgeが自動で開かない場合は、この画面に表示されるURLを手動で開いてください。
echo 終了する場合は、この黒い画面で Ctrl+C を押してください。
echo.
call :RUN_PY "%APP%" --server --port 8765 --open
set "EXITCODE=%ERRORLEVEL%"
echo.
echo サーバーが終了しました。終了コード: %EXITCODE%
echo 起動できなかった場合は、run_console.bat または diagnose.bat を実行してください。
pause
exit /b %EXITCODE%

:FIND_PYTHON
set "PY_MODE="
set "PYTHON_EXE="
where py >nul 2>nul
if not errorlevel 1 (
  set "PY_MODE=PYLAUNCHER"
  exit /b 0
)
for /f "delims=" %%P in ('where python 2^>nul') do (
  if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if defined PYTHON_EXE (
  set "PY_MODE=PYTHON"
  exit /b 0
)
exit /b 1

:RUN_PY
if "%PY_MODE%"=="PYLAUNCHER" (
  py -3 %*
) else (
  "%PYTHON_EXE%" %*
)
exit /b %ERRORLEVEL%

:NO_PYTHON
echo [ERROR] Python 3 が見つからない、または起動できません。
echo py -3 または python コマンドが使える状態にしてください。
echo 確認用に diagnose.bat を実行してください。
pause
exit /b 1
