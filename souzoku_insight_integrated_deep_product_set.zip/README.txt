相続インサイト 統合分析版

■ 起動
1. ZIPを展開します。
2. check_gate.py を実行して、配布物・分析API・入力安全・出力機能を確認します。
3. start.bat を起動します。
4. Edgeで http://127.0.0.1:8765/ または画面に表示されたURLを開きます。

■ 使うファイル
- souzoku_insight_app.py : 画面、分析API、案件DB、監査ログ、Excel/SQLite/案件パッケージ出力を含む統合アプリ本体
- start.bat : 統合アプリ起動用
- check_gate.py : 配布物と主要機能の検証用
- SHA256.txt : 配布ファイル整合性確認用

■ 保存先
運用データは、展開フォルダ内の souzoku_insight_data に保存されます。
- souzoku_insight_cases.sqlite : 案件DB
- audit_log.jsonl : 監査ログ
- current_url.txt : 起動中URL

■ 追加機能
画面から以下を確認・保存できます。
- 自己診断
- アプリ情報
- 監査ログ
- 保存データ確認
- 運用データバックアップ
- 案件パッケージ保存

■ 注意
- 画面は start.bat から起動したローカルアプリ上で開いてください。
- souzoku_insight.html のような外出しHTMLはありません。
- 高度分析の結果は確認順を整理するためのものです。最終確認は原資料・聴取内容・関係法令に基づいて行ってください。
- check_gate.py は一時領域を使い、配布フォルダを汚さない設計です。
